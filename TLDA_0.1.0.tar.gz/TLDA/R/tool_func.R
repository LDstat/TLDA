Loss_S=function(sigma,delta,beta,zeta,K,p,lambda1,lambda2,tau){
  S=0
  for(k in 1:K){
    S=S+1/2*t(beta[k,])%*%sigma[[k]]%*%beta[k,]-t(beta[k,])%*%delta[[k]]+lambda1*sum(abs(beta[k,])) 
  }
  for(k in 1:(K-1)){
    S=S+lambda2*min(tau,sum(abs(zeta[k,])))
  }
  return(S)
}


Loss_Sm=function(sigma,delta,beta,zeta,zeta_m,v,K,p,lambda1,lambda2,tau,rho){
  Sm=0
  for(k in 1:K){
    Sm=Sm+1/2*t(beta[k,])%*%sigma[[k]]%*%beta[k,]-t(beta[k,])%*%delta[[k]]+lambda1*sum(abs(beta[k,])) 
  }
  
  for(k in 1:(K-1)){
    if(sum(abs(zeta_m[k,]))<tau){
      Sm=Sm+lambda2*sum(abs(zeta[k,]))
    } else{
      Sm=Sm+lambda2*tau
    }
  }
  de_th_v=zeta+beta[1:(K-1),]-matrix(beta[K,],(K-1),p,byrow=TRUE)+v
  Sm=Sm+rho/2*(sum((de_th_v)^2)-sum((v)^2))
  return(Sm)
}

SC=function(mu_update,mu_init,tol=0.001){
  mu_inl2=norm(mu_init,"F")
  if(mu_inl2==0){
    res=norm((mu_update-mu_init),"F")
  } else{
    res=norm((mu_update-mu_init),"F")/mu_inl2
  }
  return(res<=tol)
}


AD1=function(sigma,delta,beta0,zeta,v,K,p,lambda1,rho){
  beta_hat=matrix(0,K-1,p)
  for(k in 1:(K-1)){
    #k=1
    sigma_tilde = sigma[[k]]+rho*diag(1,p)
    delta_tilde = delta[[k]]-rho*(zeta[k,]-beta0+v[k,])
    out = lasso_covariance(n = nk[k],p = p,lambda = lambda1,XX = sigma_tilde,Xy =delta_tilde,
                           beta.start = rep(0,p),penalty = "lasso")
    beta_hat[k,] = as.matrix(out$coefficients)
  }
  return(beta_hat)
}

AD0=function(sigma,delta,beta,zeta,v,K,p,lambda1,rho){
  sigma_tilde = sigma[[K]]+rho*(K-1)*diag(1,p)
  delta_tilde = delta[[K]]
  for (k in 1:(K-1)){
    delta_tilde = delta_tilde + rho*(zeta[k,]+beta[k,]+v[k,])
  }
  out = lasso_covariance(n = nk[K],p = p,lambda = lambda1,XX = sigma_tilde,Xy =delta_tilde,
                         beta.start = rep(0,p),penalty = "lasso")
  beta_hat = as.matrix(out$coefficients)
  return(beta_hat)
}


Prox=function(a,b){
  b_abs=abs(b)
  return((b_abs-a)*((b_abs-a)>0)*sign(b))
}


AD2=function(beta,zeta_m,v,K,p,lambda2,tau,rho){
  zeta_hat=zeta_m
  th_v=matrix(beta[K,],(K-1),p,byrow=TRUE)-beta[1:(K-1),]-v
  
  for(k in 1:(K-1)){
    if(sum(abs(zeta_m[k,]))<tau){
      zeta_hat[k,]=Prox(lambda2/rho,th_v[k,])
    } else{
      zeta_hat[k,]=th_v[k,]
    }
  }
  return(zeta_hat)
}


ADMM_new = function(sigma,delta,beta_ad,zeta_ad,v_ad,zeta_m,K,p,lambda1,lambda2,tau,rho,tol_ADMM,maxit_ADMM){
  l=1
  Loss_ADMM = c()
  Loss_ADMM[l] = Loss_Sm(sigma,delta,beta_ad,zeta_ad,zeta_m,v_ad,K,p,lambda1,lambda2,tau,rho)
  beta_new = matrix(0,K,p)
  zeta_new = v_new = matrix(0,K-1,p)
  while(TRUE){
    beta_new[-K,] = AD1(sigma,delta,beta_ad[K,],zeta_ad,v_ad,K,p,lambda1,rho)
    beta_new[K,] = AD0(sigma,delta,beta = beta_new,zeta_ad,v_ad,K,p,lambda1,rho)
    zeta_new = AD2(beta_new,zeta_m,v_ad,K,p,lambda2,tau,rho)
    for (k in 1:K-1){
      v_new[k,] = v_ad[k,] + zeta_new[k,] - beta_new[K,] + beta_new[k,]
    }
    Loss_ADMM[l+1] = Loss_Sm(sigma,delta,beta_new,zeta_new,zeta_m,v_new,K,p,lambda1,lambda2,tau,rho)
    if (l>maxit_ADMM){
      return(list(beta_new=beta_new,
                  zeta_new=zeta_new,
                  v_new = v_new,
                  Loss_ADMM=Loss_ADMM,
                  l=l))
    }
    res = zeta_new - (   matrix(beta_new[K,],K-1,p,byrow = TRUE) - beta_new[-K,]  )
    if (SC(beta_new,beta_ad,tol=tol_ADMM) & SC(res,matrix(0,K-1,p), tol = tol_ADMM)   ){
      return(list(beta_new=beta_new,
                  zeta_new=zeta_new,
                  v_new = v_new,
                  Loss_ADMM=Loss_ADMM,
                  l=l))
    }else{
      beta_ad = beta_new
      zeta_ad = zeta_new
      v_ad = v_new
      l = l+1
    }
  }
}


lasso_covariance <- function(n,p,lambda,control = list(maxIter = 1000,
                                                       optTol = 10^(-5), 
                                                       zeroThreshold = 10^(-6)), 
                             XX,Xy,beta.start,penalty=c("lasso", "SCAD")){
  
  beta <- beta.start
  wp <- beta
  m <- 1
  s <- XX %*% beta
  lambda0 <- lambda
  while (m < control$maxIter) {
    beta_old <- beta
    for (j in 1:p) {
      S0 <- s[j] - XX[j,j]*beta_old[j] - Xy[j]
      if (sum(is.na(S0)) >= 1) {
        beta[j] <- 0
        next
      }
      
      w_j <- 1
      if(penalty == "SCAD"){
        a <- 3.7
        if(abs(beta[j]) <= lambda){
          w_j <- 1
        }else if(abs(beta[j]) <= a*lambda){
          w_j <- (a*lambda - abs(beta[j]))/(lambda*(a-1))
        }else{
          w_j <- 0
        }
      }
      
      lambda <- w_j * lambda0
      if (S0 > lambda){
        beta[j] <- (lambda - S0)/XX[j, j]
        s <- s + XX[,j]*( beta[j] - beta_old[j])
      } 
      if (S0 < -1 * lambda){
        beta[j] <- (-1 * lambda - S0)/XX[j, j]
        s <- s + XX[,j]*( beta[j] - beta_old[j])
      }
      if (abs(S0) <= lambda) 
        beta[j] <- 0
    }
    wp <- cbind(wp, beta)
    if (sum(abs(beta - beta_old), na.rm = TRUE) < control$optTol) {
      break
    }
    m <- m + 1
  }
  w <- beta
  w[abs(w) < control$zeroThreshold] <- 0
  return(list(coefficients = w, coef.list = wp, num.it = m))
}

