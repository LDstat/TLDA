lpd = function(x, x_label, lambda, pdtol=1e-3, pdmaxiter=50){
  n <- nrow(x)
  p <- ncol(x)
  n1=sum(x_label==1)
  n2=n-n1

  u1hat=apply(x[x_label==1,],2,mean)
  u2hat=apply(x[x_label!=1,],2,mean)
  sigmahat = ((n1-1)*cov(x[x_label==1,])+(n2-1)*cov(x[x_label!=1,]))/(n1+n2-2)

  eigvals <- eigen(sigmahat, only.values=T)$values
  perturb <-  max(max(eigvals) - p*min(eigvals), 0)/(p-1)
  sigmahat <- sigmahat+diag(p)*perturb
  initial=ginv(sigmahat)%*%(u2hat-u1hat)
  diff=u2hat-u1hat
  mudelta <- linprogPD(initial,sigmahat,diff,lambda, pdtol, pdmaxiter)
  return(mudelta)
}





oracle_pool = function(x_list,ind_list,lambda,pdtol=1e-3, pdmaxiter=50){
  data = compute_sigma_mu(x_list,ind_list)
  sigma_A = data$sigma_A
  delta_A = data$delta_A

  eigvals_A <- eigen(sigma_A, only.values=T)$values
  p=nrow(sigma_A)
  perturb_A <-  max(max(eigvals_A) - p*min(eigvals_A), 0)/(p-1)
  sigma_A_perturb <- sigma_A+diag(p)*perturb_A
  initial_A=ginv(sigma_A_perturb)%*%delta_A

  mudelta <- linprogPD(initial_A,sigma_A_perturb,delta_A,lambda, pdtol, pdmaxiter)
  return(mudelta)
}



oracle_debias = function(x,x_label,hatbeta_pool,lambda,pdtol=1e-3, pdmaxiter=50){
  n <- nrow(x)
  p <- ncol(x)
  n1=sum(x_label==1)
  n2=n-n1
  u1hat=apply(x[x_label==1,],2,mean)
  u2hat=apply(x[x_label!=1,],2,mean)
  sigmahat = ((n1-1)*cov(x[x_label==1,])+(n2-1)*cov(x[x_label!=1,]))/(n1+n2-2)
  diff_0 = (u2hat-u1hat) - sigmahat%*%hatbeta_pool
  eigvals <- eigen(sigmahat, only.values=T)$values
  perturb <-  max(max(eigvals) - p*min(eigvals), 0)/(p-1)

  sigmahat <- sigmahat+diag(p)*perturb
  initial=ginv(sigmahat)%*%diff_0

  mudelta <- linprogPD(initial,sigmahat,diff_0,lambda, pdtol, pdmaxiter)
  final = hatbeta_pool+mudelta
  return(final)
}



