TLDA = function(X,y,beta_int,K,p,lambda1,lambda2,tau,rho,tol_ADMM,maxit_ADMM){
  data = compute_sigma_mu(X,y)
  sigma = data$sigma
  delta = data$delta
  zeta_int = matrix(0,K-1,p)
  for (k in 1:K-1){
    zeta_int[k,] = beta_int[K,]-beta_int[k,]
  }
  zeta_m = zeta_int
  v_int = matrix(0,K-1,p)
  m=1
  Loss_TLP = c()
  Loss_TLP[m] = Loss_S(sigma,delta,beta = beta_int,zeta = zeta_int,K,p,lambda1,lambda2,tau)
  result = list();result$fit = list()
  while(TRUE){
    fit = ADMM_new(sigma,delta,beta_ad=beta_int,zeta_ad=zeta_int,v_ad=v_int,
                   zeta_m,K,p,lambda1,lambda2,tau,rho,tol_ADMM,maxit_ADMM)
    beta_update = fit$beta_new; zeta_update = fit$zeta_new
    Loss_TLP[m+1] = Loss_S(sigma,delta,beta = beta_update,zeta = zeta_update,K,p,lambda1,lambda2,tau)
    result$fit[[m]] = fit
    if (m>10){
      return(beta_update)
    }
    if ( (Loss_TLP[m+1]-Loss_TLP[m])==0   ){
      return(beta_update)
    }else{
      zeta_m = zeta_update
      m=m+1
    }
  }
}
