arguments <- commandArgs(trailingOnly = FALSE)
file_argument <- grep("^--file=", arguments, value = TRUE)
script_dir <- if (length(file_argument)) {
  dirname(normalizePath(sub("^--file=", "", file_argument[1])))
} else {
  getwd()
}
setwd(script_dir)

local_library <- file.path(script_dir, "R_library")
if (dir.exists(local_library)) {
  .libPaths(c(local_library, .libPaths()))
}

suppressPackageStartupMessages({
  library(TLDA)
  library(MASS)
  library(doParallel)
  library(foreach)
  library(doRNG)
})
source("DGP.R")
source("one_round_package.R")

set.seed(918)
K <- 3
p <- 20
nt <- 30
ns <- 30
nk <- c(rep(ns, K - 1), nt)
s <- 4
ntest <- 20
fold <- 2
lam_min <- 0.5
lam_max <- 1
nlam <- 2
lam1_tlp_min <- 0.5
lam1_tlp_max <- 1
lam1_tlp_nlam <- 2
rho_tlp <- 5
maxit_MM_tlp <- 1
maxit_admm_tlp <- 60

beta0_fixed <- generate_beta0_random(p, s, signal_norm = sqrt(s))
sigma0_fixed <- 0.3^abs(outer(seq_len(p), seq_len(p), "-"))
sigma_pool <- vector("list", K)
sigma_pool[[K]] <- sigma0_fixed
for (k in seq_len(K - 1L)) {
  epsilon <- rnorm(p, sd = 0.1)
  sigma_pool[[k]] <- sigma0_fixed + tcrossprod(epsilon)
}

beta_inf_pool <- matrix(0, K - 1L, p)
beta_non_pool <- matrix(0, K - 1L, p)
for (k in seq_len(K - 1L)) {
  beta_inf_pool[k, ] <- generate_betak_informative(
    beta0_fixed,
    perturb_sd = 0.2,
    mismatch_prop = 0.25,
    extra_low = 0.5,
    extra_high = 1
  )
  beta_non_pool[k, ] <- generate_betak_noninformative(
    beta0_fixed,
    overlap_prop = 0.25,
    flip_prob = 0.7,
    perturb_sd = 0.2,
    extra_scale = 1
  )
}

parameters <- DGP_beta_fixed_target(
  K,
  A_num = 1,
  beta0_fixed,
  sigma_pool,
  beta_inf_pool,
  beta_non_pool
)
beta_target <- parameters$beta
sigma_target <- parameters$sigma
inf_set <- parameters$A_source

cluster <- makeCluster(2)
registerDoParallel(cluster)
invisible(clusterCall(cluster, function(paths, directory) {
  .libPaths(paths)
  setwd(directory)
  NULL
}, .libPaths(), script_dir))
invisible(clusterEvalQ(cluster, {
  library(TLDA)
  library(MASS)
  source("DGP.R")
  source("one_round_package.R")
  NULL
}))

results <- foreach(
  replication = 1:2,
  .packages = c("MASS", "TLDA"),
  .errorhandling = "pass"
) %dorng% {
  one_round_package()
}
stopCluster(cluster)

stopifnot(!any(vapply(results, inherits, logical(1), "error")))
result <- results[[1]]
stopifnot(
  all(is.finite(result$norm_re)),
  all(is.finite(result$norm_weighted)),
  all(is.finite(result$mis)),
  length(result$best_lam1tau) == 2L
)

cat("\nPARALLEL_SMOKE_TEST_OK\n")
cat("TLDA version:", as.character(packageVersion("TLDA")), "\n")
