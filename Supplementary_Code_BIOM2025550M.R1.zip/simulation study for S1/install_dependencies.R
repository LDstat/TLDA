arguments <- commandArgs(trailingOnly = FALSE)
file_argument <- grep("^--file=", arguments, value = TRUE)
script_dir <- if (length(file_argument)) {
  dirname(normalizePath(sub("^--file=", "", file_argument[1])))
} else {
  getwd()
}
setwd(script_dir)

local_library <- file.path(script_dir, "R_library")
dir.create(local_library, recursive = TRUE, showWarnings = FALSE)
.libPaths(c(local_library, .libPaths()))

package_tar <- file.path(script_dir, "TLDA_0.2.0.tar.gz")
if (!file.exists(package_tar)) {
  stop(
    "Cannot find TLDA_0.2.0.tar.gz in the simulation directory."
  )
}
package_tar <- normalizePath(package_tar)

cran_packages <- c(
  "MASS",
  "Rcpp",
  "RcppEigen",
  "RhpcBLASctl",
  "foreach",
  "doParallel",
  "doRNG"
)
missing_packages <- cran_packages[!vapply(
  cran_packages, requireNamespace, logical(1), quietly = TRUE
)]

if (length(missing_packages)) {
  install.packages(
    missing_packages,
    repos = "https://cloud.r-project.org",
    lib = local_library,
    dependencies = c("Depends", "Imports", "LinkingTo")
  )
}

install.packages(
  package_tar,
  repos = NULL,
  type = "source",
  lib = local_library
)

cat("\nInstallation completed.\n")
cat("Local R library:", local_library, "\n")
cat("TLDA source package:", package_tar, "\n")
cat("TLDA version:", as.character(packageVersion("TLDA")), "\n")
