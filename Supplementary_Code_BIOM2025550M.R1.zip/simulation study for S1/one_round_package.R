.misclassification_error <- function(x, y, beta) {
  mean_class1 <- colMeans(x[y == 1, , drop = FALSE])
  mean_class0 <- colMeans(x[y == 0, , drop = FALSE])
  center <- (mean_class1 + mean_class0) / 2
  score <- as.numeric(sweep(x, 2, center, "-") %*% beta)
  prediction <- ifelse(score > 0, 0, 1)
  mean(prediction != y)
}

.weighted_l2_error <- function(estimate, truth, sigma) {
  difference <- estimate - truth
  sqrt(as.numeric(crossprod(difference, sigma %*% difference)))
}

one_round_package <- function() {
  data <- DGP_data(K, p, nk, beta_target, sigma_target, ntest)
  x <- data$X
  y <- data$y
  x_test <- data$Xtest
  y_test <- data$ytest

  initial <- initialize_lpd(
    x,
    y,
    folds = fold,
    lambda_min = lam_min,
    lambda_max = lam_max,
    nlambda = nlam
  )
  beta_all_lpd <- initial$coefficients
  lam_lpd <- initial$lambda
  beta_target_only <- beta_all_lpd[K, ]

  if (is.null(inf_set)) {
    beta_oracle <- beta_target_only
  } else {
    beta_oracle <- oracle_tlda(
      x,
      y,
      source_set = inf_set,
      folds = fold,
      lambda_min = lam_min,
      lambda_max = lam_max,
      nlambda = nlam
    )
  }

  beta_blind <- blind_pooling(
    x,
    y,
    folds = fold,
    lambda_min = lam_min,
    lambda_max = lam_max,
    nlambda = nlam
  )

  contrast <- sort(vapply(seq_len(K - 1L), function(k) {
    sum(abs(beta_all_lpd[k, ] - beta_all_lpd[K, ]))
  }, numeric(1)))
  lambda1_grid <- seq(
    lam1_tlp_min,
    lam1_tlp_max,
    length.out = lam1_tlp_nlam
  ) * mean(lam_lpd)
  lambdaT <- rho_tlp * mean(lam_lpd)
  control <- tlda_control(
    maxit_mm = maxit_MM_tlp,
    maxit_admm = maxit_admm_tlp,
    tol_mm = 1e-4,
    tol_admm = 1e-4
  )

  cv_tlp <- cv_tlda(
    x,
    y,
    beta_init = beta_all_lpd,
    lambda1 = lambda1_grid,
    lambdaT = lambdaT,
    rho = rho_tlp,
    folds = fold,
    control = control
  )

  fit_tlp <- tlda(
    x,
    y,
    beta_init = beta_all_lpd,
    lambda1 = cv_tlp$lambda1,
    lambdaT = lambdaT,
    tau = cv_tlp$tau,
    rho = rho_tlp,
    control = control
  )
  beta_tlp <- fit_tlp$coefficients
  selected_indicator <- as.numeric(
    seq_len(K - 1L) %in% fit_tlp$selected_sources
  )

  estimates <- list(
    beta_target_only,
    beta_blind,
    beta_oracle,
    beta_tlp[K, ]
  )
  method_names <- c(
    "Naive LPD",
    "Blind Pooling",
    "Oracle TLDA",
    "Non-oracle TLDA"
  )

  mis <- matrix(vapply(estimates, function(beta) {
    .misclassification_error(x_test, y_test, beta)
  }, numeric(1)), nrow = 1, dimnames = list(NULL, method_names))

  norm_re <- matrix(vapply(estimates, function(beta) {
    norm(beta - beta_target[K, ], "2")
  }, numeric(1)), nrow = 1, dimnames = list(NULL, method_names))

  norm_weighted <- matrix(vapply(estimates, function(beta) {
    .weighted_l2_error(beta, beta_target[K, ], sigma_target[[K]])
  }, numeric(1)), nrow = 1, dimnames = list(NULL, method_names))

  beta_re <- do.call(cbind, estimates)
  colnames(beta_re) <- method_names

  list(
    norm_re = norm_re,
    norm_weighted = norm_weighted,
    mis = mis,
    hat_true_A = selected_indicator,
    beta_re = beta_re,
    beta_all_lpd = beta_all_lpd,
    beta_tlp = beta_tlp,
    lambda1opt = cv_tlp$lambda1,
    lambda2opt = lambdaT,
    tauopt = cv_tlp$tau,
    loss.mean.tar = cv_tlp$mean_loss,
    tau_grid = cv_tlp$tau_grid,
    lambda1 = lambda1_grid,
    lambda2_grid = lambdaT,
    contr = contrast,
    best_lam1tau = c(cv_tlp$lambda1_index, cv_tlp$tau_index)
  )
}
