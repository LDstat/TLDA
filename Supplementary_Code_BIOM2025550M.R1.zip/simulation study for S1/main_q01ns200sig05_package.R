Sys.setenv(
  OMP_NUM_THREADS = "1",
  OPENBLAS_NUM_THREADS = "1",
  MKL_NUM_THREADS = "1"
)

arguments <- commandArgs(trailingOnly = FALSE)
file_argument <- grep("^--file=", arguments, value = TRUE)
script_dir <- if (length(file_argument)) {
  dirname(normalizePath(sub("^--file=", "", file_argument[1])))
} else {
  getwd()
}
setwd(script_dir)

local_library <- file.path(script_dir, "R_library")
if (dir.exists(local_library)) {
  .libPaths(c(local_library, .libPaths()))
}

required_packages <- c(
  "TLDA", "MASS", "RhpcBLASctl", "doParallel", "parallel", "foreach", "doRNG"
)
missing_packages <- required_packages[!vapply(
  required_packages, requireNamespace, logical(1), quietly = TRUE
)]
if (length(missing_packages)) {
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    ". See README_LINUX.md for installation instructions."
  )
}

suppressPackageStartupMessages({
  library(TLDA)
  library(MASS)
  library(RhpcBLASctl)
  library(doParallel)
  library(parallel)
  library(foreach)
  library(doRNG)
})

RhpcBLASctl::blas_set_num_threads(1)
RhpcBLASctl::omp_set_num_threads(1)

cat("TLDA version:", as.character(packageVersion("TLDA")), "\n")
cat("OMP_NUM_THREADS =", Sys.getenv("OMP_NUM_THREADS"), "\n")
cat("BLAS threads =", RhpcBLASctl::blas_get_num_procs(), "\n")

source("DGP.R")
source("one_round_package.R")

start_time <- proc.time()
seed <- 918
set.seed(seed)

iteration <- 100
core_number <- 50
A_num_grid <- 0:5
K <- 6
p <- 400
nt <- 100
ns <- 200
nk <- c(rep(ns, K - 1), nt)

s <- 20
ntest <- 200
sig <- 0.5
heter_cov <- 0.5

beta_low <- 1
beta_high <- 2
signal_norm <- sqrt(s)
normalize <- TRUE

inf_mismatch_prop <- 0.1
inf_perturb_sd <- 0.5
inf_extra_low <- 1
inf_extra_high <- 2

non_overlap_prop <- 0.1
non_perturb_sd <- 0.5
non_flip_prob <- 0.7
non_extra_scale <- 1

cat(paste0(
  "\n========== DGP SETTINGS ==========\n",
  "K=", K, "; p=", p, "; nt=", nt, "; ns=", ns, "\n",
  "s=", s, "; ntest=", ntest, "\n",
  "COVARIANCE: sig=", sig, "; heter_cov=", heter_cov, "\n",
  "TARGET BETA: beta_low=", beta_low,
  "; beta_high=", beta_high,
  "; signal_norm=", round(signal_norm, 4),
  "; normalize=", normalize, "\n",
  "INFORMATIVE SOURCE: inf_perturb_sd=", inf_perturb_sd,
  "; inf_mismatch_prop=", inf_mismatch_prop,
  "; inf_extra_low=", inf_extra_low,
  "; inf_extra_high=", inf_extra_high, "\n",
  "NON-INFORMATIVE SOURCE: non_perturb_sd=", non_perturb_sd,
  "; non_overlap_prop=", non_overlap_prop,
  "; non_flip_prob=", non_flip_prob,
  "; non_extra_scale=", non_extra_scale, "\n",
  "==================================\n"
))

fold <- 5
lam_min <- 0.5
lam_max <- 5
nlam <- 10
lam1_tlp_min <- 0.5
lam1_tlp_max <- 2
lam1_tlp_nlam <- 5
rho_tlp <- 10
maxit_MM_tlp <- 2
maxit_admm_tlp <- 1000

beta0_fixed <- generate_beta0_random(
  p = p,
  s = s,
  low = beta_low,
  high = beta_high,
  signal_norm = signal_norm,
  normalize = normalize
)

sigma0_fixed <- sig^abs(outer(seq_len(p), seq_len(p), "-"))
sigma_pool <- vector("list", K)
sigma_pool[[K]] <- sigma0_fixed
for (k in seq_len(K - 1L)) {
  epsilon <- rnorm(p, mean = 0, sd = heter_cov)
  sigma_pool[[k]] <- sigma0_fixed + tcrossprod(epsilon)
}

beta_inf_pool <- matrix(0, nrow = K - 1L, ncol = p)
beta_non_pool <- matrix(0, nrow = K - 1L, ncol = p)
for (k in seq_len(K - 1L)) {
  beta_inf_pool[k, ] <- generate_betak_informative(
    beta0 = beta0_fixed,
    perturb_sd = inf_perturb_sd,
    mismatch_prop = inf_mismatch_prop,
    extra_low = inf_extra_low,
    extra_high = inf_extra_high
  )
  beta_non_pool[k, ] <- generate_betak_noninformative(
    beta0 = beta0_fixed,
    overlap_prop = non_overlap_prop,
    flip_prob = non_flip_prob,
    perturb_sd = non_perturb_sd,
    magnitude_low = beta_low,
    magnitude_high = beta_high,
    extra_scale = non_extra_scale
  )
}

cluster <- makeCluster(core_number)
registerDoParallel(cluster)

library_paths <- .libPaths()
invisible(clusterCall(cluster, function(paths, directory) {
  .libPaths(paths)
  setwd(directory)
  NULL
}, library_paths, script_dir))

invisible(clusterEvalQ(cluster, {
  Sys.setenv(
    OMP_NUM_THREADS = "1",
    OPENBLAS_NUM_THREADS = "1",
    MKL_NUM_THREADS = "1"
  )
  library(TLDA)
  library(MASS)
  source("DGP.R")
  source("one_round_package.R")
  NULL
}))

all_results <- vector("list", length(A_num_grid))
names(all_results) <- paste0("A_num_", A_num_grid)

for (A_num in A_num_grid) {
  cat("\n\n=====================================\n")
  cat("Running A_num =", A_num, "\n")
  cat("=====================================\n")

  parameters <- DGP_beta_fixed_target(
    K = K,
    A_num = A_num,
    beta0_fixed = beta0_fixed,
    sigma_pool = sigma_pool,
    beta_inf_pool = beta_inf_pool,
    beta_non_pool = beta_non_pool,
    A_source_mode = "nested"
  )
  beta_target <- parameters$beta
  sigma_target <- parameters$sigma
  inf_set <- parameters$A_source
  not_inf <- parameters$not_inf
  true_A <- parameters$true_A

  cat("target beta norm =", round(sqrt(sum(beta_target[K, ]^2)), 4), "\n")
  beta_diff_l1 <- vapply(seq_len(K - 1L), function(k) {
    sum(abs(beta_target[k, ] - beta_target[K, ]))
  }, numeric(1))
  cat("source-target beta l1 distance =", round(beta_diff_l1, 4), "\n")

  delta_target <- sqrt(as.numeric(
    beta_target[K, ] %*% sigma_target[[K]] %*% beta_target[K, ]
  ))
  R_opt_target <- pnorm(-delta_target / 2)
  cat("Bayes mis error =", round(R_opt_target, 4), "\n")
  cat("true_A =", true_A, "\n")

  result_list <- foreach(
    replication = seq_len(iteration),
    .packages = c("MASS", "TLDA"),
    .errorhandling = "pass"
  ) %dorng% {
    one_round_package()
  }

  ok <- vapply(result_list, function(value) !inherits(value, "error"), logical(1))
  results <- result_list[ok]
  cat("success iteration =", length(results), "\n")
  if (!length(results)) {
    stop("All replications failed for A_num = ", A_num)
  }

  lambdaopt <- vapply(results, `[[`, numeric(1), "lambda1opt")
  tauopt <- vapply(results, `[[`, numeric(1), "tauopt")
  lambda_grid <- do.call(rbind, lapply(results, `[[`, "lambda1"))
  tau_grid <- do.call(rbind, lapply(results, `[[`, "tau_grid"))
  contr <- do.call(rbind, lapply(results, `[[`, "contr"))
  best_tunning <- do.call(rbind, lapply(results, `[[`, "best_lam1tau"))
  norm_re <- do.call(rbind, lapply(results, `[[`, "norm_re"))
  norm_weighted <- do.call(rbind, lapply(results, `[[`, "norm_weighted"))
  mis <- do.call(rbind, lapply(results, `[[`, "mis"))
  hat_true_A <- do.call(rbind, lapply(results, `[[`, "hat_true_A"))

  norm_mean <- colMeans(norm_re)
  norm_sd <- apply(norm_re, 2, sd)
  norm_weighted_mean <- colMeans(norm_weighted)
  norm_weighted_sd <- apply(norm_weighted, 2, sd)
  mis_mean <- colMeans(mis)
  mis_sd <- apply(mis, 2, sd)
  hat_A_sum <- colSums(hat_true_A)

  cat(" =========== norm_re ===========\n")
  print(norm_mean)
  cat(" =========== norm_weighted ===========\n")
  print(norm_weighted_mean)
  cat(" =========== mis error ===========\n")
  print(mis_mean)
  cat(" =========== hat_true_A ===========\n")
  print(hat_A_sum)

  all_results[[paste0("A_num_", A_num)]] <- list(
    A_num = A_num,
    true_A = true_A,
    inf_set = inf_set,
    not_inf = not_inf,
    R_opt_target = R_opt_target,
    success = length(results),
    ok = ok,
    lambdaopt = lambdaopt,
    tauopt = tauopt,
    lambda_grid = lambda_grid,
    tau_grid = tau_grid,
    contr = contr,
    best_tunning = best_tunning,
    norm_re = norm_re,
    norm_weighted = norm_weighted,
    mis = mis,
    hat_true_A = hat_true_A,
    norm_mean = norm_mean,
    norm_sd = norm_sd,
    norm_weighted_mean = norm_weighted_mean,
    norm_weighted_sd = norm_weighted_sd,
    mis_mean = mis_mean,
    mis_sd = mis_sd,
    hat_A_sum = hat_A_sum,
    beta_re_list = lapply(results, `[[`, "beta_re"),
    beta_all_lpd_list = lapply(results, `[[`, "beta_all_lpd"),
    beta_tlp_list = lapply(results, `[[`, "beta_tlp"),
    loss.mean.tar_list = lapply(results, `[[`, "loss.mean.tar"),
    res_raw = result_list
  )

}

stopCluster(cluster)

norm_summary <- do.call(rbind, lapply(A_num_grid, function(a) {
  all_results[[paste0("A_num_", a)]]$norm_mean
}))
norm_weighted_summary <- do.call(rbind, lapply(A_num_grid, function(a) {
  all_results[[paste0("A_num_", a)]]$norm_weighted_mean
}))
mis_summary <- do.call(rbind, lapply(A_num_grid, function(a) {
  all_results[[paste0("A_num_", a)]]$mis_mean
}))

rownames(norm_summary) <- paste0("A_num=", A_num_grid)
rownames(norm_weighted_summary) <- paste0("A_num=", A_num_grid)
rownames(mis_summary) <- paste0("A_num=", A_num_grid)

cat("\n=========== Final norm summary ===========\n")
print(round(norm_summary, 4))
cat("\n=========== Final norm_weighted summary ===========\n")
print(round(norm_weighted_summary, 4))
cat("\n=========== Final mis summary ===========\n")
print(round(mis_summary, 4))

write.csv(norm_weighted_summary, "S1_q01_norm_weighted_summary.csv")
write.csv(mis_summary, "S1_q01_mis_summary.csv")

elapsed <- (proc.time() - start_time)[["elapsed"]]
cat("running_time:", elapsed, "s\n")
