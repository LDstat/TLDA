DGP_beta_fixed_target <- function(K, A_num,
                                  beta0_fixed,
                                  sigma_pool,
                                  beta_inf_pool,
                                  beta_non_pool,
                                  A_source_mode = "nested") {
  
  p <- length(beta0_fixed)
  beta <- matrix(0, nrow = K, ncol = p)
  sigma <- sigma_pool
  
  # target beta
  beta[K, ] <- beta0_fixed
  
  # informative source set
  if (A_num == 0) {
    A_source <- NULL
  } else {
    if (A_source_mode == "nested") {
      A_source <- 1:A_num
    } else {
      A_source <- sort(sample(1:(K - 1), A_num, replace = FALSE))
    }
  }
  
  # non-informative source set
  if (is.null(A_source)) {
    not_inf <- 1:(K - 1)
  } else {
    not_inf <- setdiff(1:(K - 1), A_source)
  }
  
  # true source indicator
  true_A <- rep(0, K - 1)
  if (!is.null(A_source)) {
    true_A[A_source] <- 1
  }
  
  # generate source beta from fixed pools
  for (k in 1:(K - 1)) {
    if (true_A[k] == 1) {
      beta[k, ] <- beta_inf_pool[k, ]
    } else {
      beta[k, ] <- beta_non_pool[k, ]
    }
  }
  
  return(list(
    beta = beta,
    sigma = sigma,
    A_source = A_source,
    not_inf = not_inf,
    true_A = true_A
  ))
}


generate_beta0_random <- function(p, s,
                                  low = 1,
                                  high = 2,
                                  signal_norm = sqrt(s),
                                  normalize = TRUE) {
  
  beta0 <- rep(0, p)
  
  # Random support set
  S0 <- sort(sample(1:p, s, replace = FALSE))
  
  # Random magnitudes and random signs
  abs_val <- runif(s, min = low, max = high)
  signs <- sample(c(-1, 1), size = s, replace = TRUE)
  
  raw <- abs_val * signs
  
  if (normalize) {
    raw <- signal_norm * raw / sqrt(sum(raw^2))
  }
  
  beta0[S0] <- raw
  
  return(beta0)
}

generate_betak_informative <- function(beta0,
                                       perturb_sd = 0.10,
                                       mismatch_prop = 0.10,
                                       extra_low = 0.2,
                                       extra_high = 0.5) {
  
  p <- length(beta0)
  S0 <- which(beta0 != 0)
  s <- length(S0)
  
  if (s == 0) {
    stop("beta0 has no nonzero entries.")
  }
  
  betak <- rep(0, p)
  
  # number of mildly mismatched active coordinates
  q_mis <- floor(mismatch_prop * s)
  
  if (q_mis > 0) {
    Rk <- sample(S0, size = q_mis, replace = FALSE)
  } else {
    Rk <- integer(0)
  }
  
  S_shared <- setdiff(S0, Rk)
  
  # shared support: same signs, mild magnitude perturbation
  u <- runif(length(S_shared), min = -perturb_sd, max = perturb_sd)
  betak[S_shared] <- beta0[S_shared] * (1 + u)
  
  # weak source-specific signals
  if (q_mis > 0) {
    E_pool <- setdiff(1:p, S0)
    Ek <- sample(E_pool, size = q_mis, replace = FALSE)
    
    extra_signs <- sample(c(-1, 1), size = q_mis, replace = TRUE)
    extra_mag <- runif(q_mis, min = extra_low, max = extra_high)
    
    betak[Ek] <- extra_signs * extra_mag
  }
  
  return(betak)
}




generate_betak_noninformative <- function(beta0,
                                          overlap_prop = 0.3,
                                          flip_prob = 0.5,
                                          perturb_sd  = 0.3,
                                          magnitude_low = 1,
                                          magnitude_high= 2,
                                          extra_scale = 1.5) {
  
  p <- length(beta0)
  S0 <- which(beta0 != 0)
  s <- length(S0)
  
  if (s == 0) {
    stop("beta0 has no nonzero entries.")
  }
  
  betak <- rep(0, p)
  
  # 1. Keep only part of the target support
  q_overlap <- max(1, floor(overlap_prop * s))
  S_overlap <- sample(S0, size = q_overlap, replace = FALSE)
  
  # 2. Add source-specific active coordinates outside target support
  q_extra <- s - q_overlap
  S_extra_pool <- setdiff(1:p, S0)
  
  if (q_extra > 0) {
    S_extra <- sample(S_extra_pool, size = q_extra, replace = FALSE)
  } else {
    S_extra <- integer(0)
  }
  
  # 3. On overlapping support: magnitude perturbation + partial sign flip
  u <- runif(q_overlap, min = -perturb_sd , max = perturb_sd )
  flip_sign <- ifelse(runif(q_overlap) < flip_prob, -1, 1)
  
  betak[S_overlap] <- flip_sign * beta0[S_overlap] * (1 + u)
  
  # 4. On source-specific support: new signals
  if (q_extra > 0) {
    extra_signs <- sample(c(-1, 1), size = q_extra, replace = TRUE)
    extra_mag <- runif(q_extra, min = magnitude_low, max = magnitude_high)
    betak[S_extra] <- extra_signs * extra_scale * extra_mag
  }
  
  return(betak)
}








DGP_data = function(K, p, nk, beta, sigma, ntest) {
  X = vector("list", K)
  y = vector("list", K)
  n_ind = matrix(0, K, 2)
  
  mu_zero = rep(0, p)
  
  # ---------- target domain ----------
  nK_all = nk[K] + ntest
  y_t_all = rbinom(nK_all, 1, 0.5)
  X_t_all = matrix(0, nK_all, p)
  
  muK = as.vector(sigma[[K]] %*% beta[K, ])
  idx1 = which(y_t_all == 1)
  idx0 = which(y_t_all == 0)
  
  if (length(idx1) > 0) {
    X_t_all[idx1, ] = mvrnorm(length(idx1), mu = mu_zero, Sigma = sigma[[K]])
  }
  if (length(idx0) > 0) {
    X_t_all[idx0, ] = mvrnorm(length(idx0), mu = muK, Sigma = sigma[[K]])
  }
  
  X[[K]] = X_t_all[1:nk[K], , drop = FALSE]
  y[[K]] = y_t_all[1:nk[K]]
  Xtest = X_t_all[(nk[K] + 1):nK_all, , drop = FALSE]
  ytest = y_t_all[(nk[K] + 1):nK_all]
  
  # ---------- source domains ----------
  for (k in 1:(K - 1)) {
    y[[k]] = rbinom(nk[k], 1, 0.5)
    X[[k]] = matrix(0, nk[k], p)
    
    muk = as.vector(sigma[[k]] %*% beta[k, ])
    idx1 = which(y[[k]] == 1)
    idx0 = which(y[[k]] == 0)
    
    if (length(idx1) > 0) {
      X[[k]][idx1, ] = mvrnorm(length(idx1), mu = mu_zero, Sigma = sigma[[k]])
    }
    if (length(idx0) > 0) {
      X[[k]][idx0, ] = mvrnorm(length(idx0), mu = muk, Sigma = sigma[[k]])
    }
  }
  
  # ---------- counts ----------
  for (k in 1:K) {
    n_ind[k, 1] = sum(y[[k]] == 1)
    n_ind[k, 2] = nk[k] - n_ind[k, 1]
  }
  
  return(list(X = X, y = y, n_ind = n_ind, Xtest = Xtest, ytest = ytest))
}