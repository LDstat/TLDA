#' Control parameters for TLDA optimization
#'
#' @param maxit_mm Maximum number of majorization-minimization iterations.
#' @param maxit_admm Maximum number of ADMM iterations per MM step.
#' @param tol_mm Relative objective tolerance for MM.
#' @param tol_admm Convergence tolerance for ADMM.
#'
#' @return A control list used by [tlda()] and [cv_tlda()].
#' @export
tlda_control <- function(maxit_mm = 2L, maxit_admm = 1000L,
                         tol_mm = 1e-4, tol_admm = 1e-4) {
  values <- c(maxit_mm, maxit_admm, tol_mm, tol_admm)
  if (any(!is.finite(values)) || maxit_mm < 1 || maxit_admm < 1 ||
      tol_mm <= 0 || tol_admm <= 0) {
    stop("Invalid TLDA optimization controls.", call. = FALSE)
  }
  list(
    maxit_mm = as.integer(maxit_mm),
    maxit_admm = as.integer(maxit_admm),
    tol_mm = tol_mm,
    tol_admm = tol_admm
  )
}

.validate_beta_init <- function(beta_init, x) {
  expected <- c(length(x), ncol(x[[1]]))
  if (!is.matrix(beta_init) || !all(dim(beta_init) == expected) ||
      anyNA(beta_init) || any(!is.finite(beta_init))) {
    stop(
      "beta_init must be a finite K by p matrix with the target in row K.",
      call. = FALSE
    )
  }
}

.tlda_tau_grid <- function(beta_init) {
  if (!is.matrix(beta_init) || nrow(beta_init) < 2L) {
    stop("beta_init must contain at least one source and one target.", call. = FALSE)
  }
  target <- nrow(beta_init)
  contrasts <- sort(vapply(seq_len(target - 1L), function(k) {
    sum(abs(beta_init[k, ] - beta_init[target, ]))
  }, numeric(1)))
  grid <- numeric(target)
  grid[1] <- contrasts[1] / 5
  if (target > 2L) {
    for (k in seq_len(target - 2L)) {
      grid[k + 1L] <- (contrasts[k] + contrasts[k + 1L]) / 2
    }
  }
  grid[target] <- contrasts[target - 1L] * 5
  grid
}

#' Fit the Non-oracle TLDA method
#'
#' Fits Non-oracle TLDA by jointly estimating the domain-specific discriminant
#' directions and using the truncated contrast penalty to identify transferable
#' source domains. Source domains must be listed first and the target domain
#' last.
#'
#' @param x List of numeric predictor matrices.
#' @param y List of binary response vectors coded as 0 and 1.
#' @param beta_init Initial K by p coefficient matrix, commonly returned by
#'   [initialize_lpd()].
#' @param lambda1 Sparsity penalty for the domain-specific directions.
#' @param lambdaT Penalty parameter controlling the shrinkage of source-target
#'   coefficient differences under the truncated contrast penalty.
#' @param tau Truncation threshold.
#' @param rho ADMM step-size parameter, with a default value of 10.
#' @param control Optimization controls from [tlda_control()].
#'
#' @return An object of class `tlda` containing the estimated target-domain
#'   discriminant direction, the domain-specific discriminant directions, and
#'   the indices of the selected transferable source domains.
#' @usage
#' tlda(x, y, beta_init, lambda1, lambdaT, tau, rho,
#'      control = tlda_control())
#' @export
tlda <- function(x, y, beta_init, lambda1, lambdaT, tau, rho = 10,
                 control = tlda_control()) {
  .validate_domains(x, y)
  .validate_beta_init(beta_init, x)
  tuning <- c(lambda1, lambdaT, tau, rho)
  if (any(!is.finite(tuning)) || any(tuning < 0) || rho == 0) {
    stop("Tuning parameters must be finite and nonnegative, with rho > 0.",
         call. = FALSE)
  }
  stats <- .compute_stats(x, y)
  result <- .tlda_engine(
    stats, beta_init, lambda1, lambdaT, tau, rho, control, FALSE
  )
  target <- length(x)
  structure(list(
    coefficients = result$beta,
    target_coefficients = result$beta[target, ],
    contrasts = result$zeta,
    selected_sources = which(rowSums(abs(result$zeta)) < tau),
    target_center = stats$center[[target]],
    lambda1 = lambda1,
    lambdaT = lambdaT,
    tau = tau,
    rho = rho,
    objective = result$objective,
    convergence = result[c(
      "mm_iterations", "admm_iterations", "admm_converged", "primal_norm"
    )],
    call = match.call()
  ), class = "tlda")
}

#' Select the TLDA tuning parameters \eqn{\lambda_1} and \eqn{\tau} by cross-validation
#'
#' Selects \eqn{\lambda_1} and \eqn{\tau} by minimizing the target-domain
#' cross-validation loss while keeping \eqn{\lambda_T} fixed.
#'
#' @inheritParams tlda
#' @param lambda1 Numeric vector of candidate sparsity penalties.
#' @param tau Optional numeric vector of candidate truncation thresholds. If
#'   `NULL`, the candidate grid is constructed from the source-target
#'   differences in the initial domain-specific LPD estimates.
#' @param folds Number of cross-validation folds.
#' @param seed Optional random seed used to form folds.
#'
#' @return An object of class `cv_tlda` containing the selected values of
#'   \eqn{\lambda_1} and \eqn{\tau}, the fixed value of \eqn{\lambda_T}, and
#'   the mean target-domain cross-validation loss for each candidate pair.
#' @usage
#' cv_tlda(x, y, beta_init, lambda1, lambdaT, tau = NULL, rho,
#'         folds = 5L, control = tlda_control(), seed = NULL)
#' @export
cv_tlda <- function(x, y, beta_init, lambda1, lambdaT, tau = NULL,
                    rho = 10, folds = 5L,
                    control = tlda_control(), seed = NULL) {
  .validate_domains(x, y)
  .validate_beta_init(beta_init, x)
  if (!is.null(seed)) set.seed(seed)
  if (is.null(tau)) tau <- .tlda_tau_grid(beta_init)
  if (!length(lambda1) || !length(tau) ||
      any(!is.finite(c(lambda1, lambdaT, tau, rho))) ||
      any(c(lambda1, lambdaT, tau, rho) < 0) || rho == 0) {
    stop("Invalid TLDA tuning grid.", call. = FALSE)
  }
  k <- length(x)
  parts <- lapply(y, .balanced_cv_part, folds = folds)
  loss <- array(NA_real_, dim = c(folds, length(lambda1), length(tau)))
  for (fold in seq_len(folds)) {
    train_x <- train_y <- test_x <- test_y <- vector("list", k)
    for (domain in seq_len(k)) {
      train <- parts[[domain]]$train[[fold]]
      test <- parts[[domain]]$test[[fold]]
      train_x[[domain]] <- x[[domain]][train, , drop = FALSE]
      train_y[[domain]] <- y[[domain]][train]
      test_x[[domain]] <- x[[domain]][test, , drop = FALSE]
      test_y[[domain]] <- y[[domain]][test]
    }
    stats <- .compute_stats(train_x, train_y)
    for (tau_index in seq_along(tau)) {
      for (lambda_index in seq_along(lambda1)) {
        fit <- .tlda_engine(
          stats, beta_init, lambda1[lambda_index], lambdaT,
          tau[tau_index], rho, control, FALSE
        )
        loss[fold, lambda_index, tau_index] <- .cv_criterion(
          test_x[[k]], test_y[[k]], fit$beta[k, ]
        )
      }
    }
  }
  mean_loss <- apply(loss, c(2, 3), mean)
  dim(mean_loss) <- c(length(lambda1), length(tau))
  best <- arrayInd(which.min(mean_loss), dim(mean_loss))[1, ]
  structure(list(
    lambda1 = lambda1[best[1]],
    lambdaT = lambdaT,
    tau = tau[best[2]],
    lambda1_index = best[1],
    tau_index = best[2],
    lambda1_grid = lambda1,
    tau_grid = tau,
    mean_loss = mean_loss,
    fold_loss = loss,
    folds = folds,
    call = match.call()
  ), class = "cv_tlda")
}

#' @export
#' @noRd
coef.tlda <- function(object, type = c("target", "all"), ...) {
  type <- match.arg(type)
  if (type == "target") object$target_coefficients else object$coefficients
}

#' @export
#' @noRd
predict.tlda <- function(object, newdata, type = c("class", "score"), ...) {
  type <- match.arg(type)
  if (!is.matrix(newdata) || ncol(newdata) != length(object$target_coefficients)) {
    stop("newdata has an incompatible number of variables.", call. = FALSE)
  }
  score <- as.numeric(sweep(newdata, 2, object$target_center, "-") %*%
    object$target_coefficients)
  if (type == "score") return(score)
  ifelse(score > 0, 0, 1)
}

#' @export
#' @noRd
print.tlda <- function(x, ...) {
  cat("Transfer-enhanced linear discriminant analysis\n")
  cat("Selected sources:",
      if (length(x$selected_sources)) paste(x$selected_sources, collapse = ", ") else "none",
      "\n")
  cat("lambda1 =", format(x$lambda1),
      "; lambdaT =", format(x$lambdaT),
      "; tau =", format(x$tau), "\n")
  invisible(x)
}

#' @export
#' @noRd
print.cv_tlda <- function(x, ...) {
  cat("Cross-validated TLDA\n")
  cat("lambda1 =", format(x$lambda1),
      "; fixed lambdaT =", format(x$lambdaT),
      "; tau =", format(x$tau), "\n")
  invisible(x)
}
