.lpd_prepare_debias <- function(x, y, pooled_beta) {
  .validate_xy(x, y)
  stats <- .compute_one(x, y)
  delta_debias <- stats$delta - stats$sigma %*% pooled_beta
  initial <- tryCatch(
    solve(stats$sigma, delta_debias),
    error = function(e) MASS::ginv(stats$sigma) %*% delta_debias
  )
  list(
    sigma = stats$sigma,
    delta = as.vector(delta_debias),
    initial = as.vector(initial)
  )
}

.cv_lpd_debias <- function(x, y, pooled_beta, folds, lambda = NULL,
                           lambda_min = 0.5, lambda_max = 5,
                           nlambda = 10L, pdtol = 1e-3,
                           pdmaxiter = 50L) {
  part <- .balanced_cv_part(y, folds)
  if (is.null(lambda)) {
    lambda <- seq(lambda_min, lambda_max, length.out = nlambda) *
      sqrt(log(ncol(x)) / nrow(x))
  }
  loss <- matrix(NA_real_, folds, length(lambda))
  for (j in seq_len(folds)) {
    train <- part$train[[j]]
    test <- part$test[[j]]
    prepared <- .lpd_prepare_debias(x[train, , drop = FALSE], y[train], pooled_beta)
    initial <- prepared$initial
    for (g in seq_along(lambda)) {
      correction <- .lpd_fit_prepared(
        prepared, lambda[g], pdtol, pdmaxiter, initial
      )
      loss[j, g] <- .cv_criterion(
        x[test, , drop = FALSE], y[test], pooled_beta + correction
      )
      initial <- correction
    }
  }
  mean_loss <- colMeans(loss)
  best <- which.min(mean_loss)
  list(lambda = lambda[best], grid = lambda, mean_loss = mean_loss, fold_loss = loss)
}

.pool_domains <- function(x, y, domains) {
  list(
    x = do.call(rbind, x[domains]),
    y = unlist(y[domains], use.names = FALSE)
  )
}

#' Fit the blind-pooling benchmark
#'
#' @inheritParams initialize_lpd
#' @return A numeric discriminant direction fitted after pooling all domains.
#' @export
blind_pooling <- function(x, y, folds = 5L, lambda = NULL,
                          lambda_min = 0.5, lambda_max = 5,
                          nlambda = 10L, pdtol = 1e-3,
                          pdmaxiter = 50L, seed = NULL) {
  .validate_domains(x, y)
  if (!is.null(seed)) set.seed(seed)
  pooled <- .pool_domains(x, y, seq_along(x))
  cv <- cv_lpd(
    pooled$x, pooled$y, folds, lambda, lambda_min, lambda_max,
    nlambda, pdtol, pdmaxiter
  )
  lpd(pooled$x, pooled$y, cv$lambda, pdtol, pdmaxiter)
}

#' Fit the Oracle TLDA method
#'
#' Fits Oracle TLDA in two steps. First, data from the informative source
#' domains specified by `source_set` are pooled with the target-domain data to
#' obtain a pooled estimate. Second, the target-domain data are used to estimate
#' a correction that debiases the pooled estimate. Source domains must be listed
#' first and the target domain last.
#'
#' @inheritParams initialize_lpd
#' @param source_set Integer indices of informative source domains.
#'
#' @return A numeric oracle TLDA discriminant direction.
#' @export
oracle_tlda <- function(x, y, source_set, folds = 5L, lambda = NULL,
                        lambda_min = 0.5, lambda_max = 5,
                        nlambda = 10L, pdtol = 1e-3,
                        pdmaxiter = 50L, seed = NULL) {
  .validate_domains(x, y)
  if (!is.null(seed)) set.seed(seed)
  target <- length(x)
  if (!length(source_set)) {
    cv <- cv_lpd(
      x[[target]], y[[target]], folds, lambda, lambda_min, lambda_max,
      nlambda, pdtol, pdmaxiter
    )
    return(lpd(x[[target]], y[[target]], cv$lambda, pdtol, pdmaxiter))
  }
  if (any(source_set < 1L | source_set >= target)) {
    stop("source_set contains invalid source indices.", call. = FALSE)
  }
  pooled <- .pool_domains(x, y, c(sort(unique(source_set)), target))
  cv_pool <- cv_lpd(
    pooled$x, pooled$y, folds, lambda, lambda_min, lambda_max,
    nlambda, pdtol, pdmaxiter
  )
  pooled_beta <- lpd(pooled$x, pooled$y, cv_pool$lambda, pdtol, pdmaxiter)
  cv_debias <- .cv_lpd_debias(
    x[[target]], y[[target]], pooled_beta, folds, lambda,
    lambda_min, lambda_max, nlambda, pdtol, pdmaxiter
  )
  prepared <- .lpd_prepare_debias(x[[target]], y[[target]], pooled_beta)
  correction <- .lpd_fit_prepared(
    prepared, cv_debias$lambda, pdtol, pdmaxiter
  )
  pooled_beta + correction
}
