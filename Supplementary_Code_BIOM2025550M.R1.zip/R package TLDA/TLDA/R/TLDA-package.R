#' TLDA: Transfer-Enhanced Linear Discriminant Analysis
#'
#' Implements transfer-enhanced linear discriminant analysis for
#' high-dimensional binary classification using a target domain and multiple
#' source domains. Non-oracle TLDA identifies transferable source domains using
#' a truncated contrast penalty. The package also provides LPD initialization,
#' cross-validation, Oracle TLDA, and Blind-Pooling methods.
#'
#' @useDynLib TLDA, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @keywords internal
"_PACKAGE"
