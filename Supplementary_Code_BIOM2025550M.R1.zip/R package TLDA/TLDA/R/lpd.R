.lpd_prepare <- function(x, y) {
  .validate_xy(x, y)
  stats <- .compute_one(x, y)
  initial <- tryCatch(
    solve(stats$sigma, stats$delta),
    error = function(e) MASS::ginv(stats$sigma) %*% stats$delta
  )
  list(
    sigma = stats$sigma,
    delta = as.vector(stats$delta),
    initial = as.vector(initial),
    center = stats$center
  )
}

.lpd_fit_prepared <- function(prepared, lambda, pdtol = 1e-3,
                              pdmaxiter = 50L, initial = NULL) {
  if (is.null(initial)) initial <- prepared$initial
  infeasibility <- max(abs(prepared$sigma %*% initial - prepared$delta))
  if (infeasibility > lambda) lambda <- 1.01 * infeasibility
  as.vector(linprogPD_rcpp(
    x0_ = as.vector(initial),
    A_ = prepared$sigma,
    b_ = prepared$delta,
    epsilon = lambda,
    pdtol = pdtol,
    pdmaxiter = as.integer(pdmaxiter)
  ))
}

#' Fit the linear programming discriminant (LPD) estimator
#'
#' @param x Numeric predictor matrix.
#' @param y Binary response vector coded as 0 and 1.
#' @param lambda Tuning parameter for the LPD estimator.
#' @param pdtol Convergence tolerance for the primal-dual LPD solver.
#' @param pdmaxiter Maximum number of iterations for the primal-dual LPD solver.
#'
#' @return A numeric vector containing the estimated discriminant direction.
#' @references
#' Cai, T. T. and Liu, W. (2011). A direct estimation approach to sparse linear
#' discriminant analysis. \emph{Journal of the American Statistical
#' Association}, \strong{106}(496), 1566-1577.
#' @export
lpd <- function(x, y, lambda, pdtol = 1e-3, pdmaxiter = 50L) {
  if (length(lambda) != 1L || !is.finite(lambda) || lambda < 0) {
    stop("lambda must be one nonnegative finite number.", call. = FALSE)
  }
  .lpd_fit_prepared(.lpd_prepare(x, y), lambda, pdtol, pdmaxiter)
}

#' Select the LPD tuning parameter by cross-validation
#'
#' Selects the tuning parameter `lambda` for the LPD estimator by
#' cross-validation.
#'
#' @param x Numeric predictor matrix.
#' @param y Binary response vector coded as 0 and 1.
#' @param folds Number of cross-validation folds.
#' @param lambda Optional numeric vector of candidate tuning parameters.
#' @param lambda_min,lambda_max Multipliers defining the candidate grid when
#'   `lambda` is not supplied.
#' @param nlambda Number of grid points.
#' @param pdtol Convergence tolerance for the primal-dual LPD solver.
#' @param pdmaxiter Maximum number of iterations for the primal-dual LPD solver.
#' @param seed Optional random seed used to form folds.
#'
#' @return An object of class `cv_lpd` containing the selected tuning parameter
#'   `lambda` and the mean cross-validation loss for each value in the
#'   candidate grid.
#' @export
cv_lpd <- function(x, y, folds = 5L, lambda = NULL,
                   lambda_min = 0.5, lambda_max = 5, nlambda = 10L,
                   pdtol = 1e-3, pdmaxiter = 50L, seed = NULL) {
  .validate_xy(x, y)
  if (!is.null(seed)) set.seed(seed)
  part <- .balanced_cv_part(y, as.integer(folds))
  if (is.null(lambda)) {
    base <- sqrt(log(ncol(x)) / nrow(x))
    lambda <- seq(lambda_min, lambda_max, length.out = nlambda) * base
  }
  if (!length(lambda) || any(!is.finite(lambda)) || any(lambda < 0)) {
    stop("lambda must contain nonnegative finite values.", call. = FALSE)
  }
  loss <- matrix(NA_real_, nrow = folds, ncol = length(lambda))
  for (j in seq_len(folds)) {
    train <- part$train[[j]]
    test <- part$test[[j]]
    prepared <- .lpd_prepare(x[train, , drop = FALSE], y[train])
    initial <- prepared$initial
    for (g in seq_along(lambda)) {
      beta <- .lpd_fit_prepared(
        prepared, lambda[g], pdtol, pdmaxiter, initial
      )
      loss[j, g] <- .cv_criterion(x[test, , drop = FALSE], y[test], beta)
      initial <- beta
    }
  }
  mean_loss <- colMeans(loss)
  best <- which.min(mean_loss)
  structure(list(
    lambda = lambda[best],
    index = best,
    grid = lambda,
    mean_loss = mean_loss,
    fold_loss = loss,
    folds = folds
  ), class = "cv_lpd")
}

#' Compute initial LPD estimates for TLDA
#'
#' Computes domain-specific LPD estimates used to initialize `cv_tlda()` and
#' `tlda()`. Source domains must be listed first and the target domain last.
#'
#' @param x List of predictor matrices.
#' @param y List of binary response vectors.
#' @param folds Number of cross-validation folds.
#' @param lambda Optional common candidate vector.
#' @param lambda_min,lambda_max Multipliers defining the default grids.
#' @param nlambda Number of candidate values.
#' @param pdtol Convergence tolerance for the primal-dual LPD solver.
#' @param pdmaxiter Maximum number of iterations for the primal-dual LPD solver.
#' @param seed Optional random seed.
#'
#' @return A list containing `coefficients`, the \eqn{K}-by-\eqn{p} matrix of
#'   domain-specific LPD estimates, and `lambda`, the vector of selected LPD
#'   tuning parameters. The coefficient matrix is used as `beta_init` in
#'   `cv_tlda()` and `tlda()`.
#' @export
initialize_lpd <- function(x, y, folds = 5L, lambda = NULL,
                           lambda_min = 0.5, lambda_max = 5,
                           nlambda = 10L, pdtol = 1e-3,
                           pdmaxiter = 50L, seed = NULL) {
  .validate_domains(x, y)
  if (!is.null(seed)) set.seed(seed)
  k <- length(x)
  p <- ncol(x[[1]])
  coefficients <- matrix(0, nrow = k, ncol = p)
  selected <- numeric(k)
  cv <- vector("list", k)
  for (domain in seq_len(k)) {
    cv[[domain]] <- cv_lpd(
      x[[domain]], y[[domain]], folds, lambda,
      lambda_min, lambda_max, nlambda, pdtol, pdmaxiter
    )
    selected[domain] <- cv[[domain]]$lambda
    coefficients[domain, ] <- lpd(
      x[[domain]], y[[domain]], selected[domain], pdtol, pdmaxiter
    )
  }
  list(coefficients = coefficients, lambda = selected, cv = cv)
}

#' @export
#' @noRd
print.cv_lpd <- function(x, ...) {
  cat("Cross-validated LPD\n")
  cat("Selected lambda:", format(x$lambda), "\n")
  invisible(x)
}
