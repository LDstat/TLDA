.validate_xy <- function(x, y, name = "data") {
  if (!is.matrix(x) || !is.numeric(x)) {
    stop(name, " must be a numeric matrix.", call. = FALSE)
  }
  if (nrow(x) != length(y)) {
    stop(name, " and its label vector have incompatible sizes.", call. = FALSE)
  }
  if (anyNA(x) || any(!is.finite(x))) {
    stop(name, " contains missing or non-finite values.", call. = FALSE)
  }
  if (anyNA(y) || !all(y %in% c(0, 1))) {
    stop("Labels must be coded as 0 and 1.", call. = FALSE)
  }
  if (!all(c(0, 1) %in% y)) {
    stop(name, " must contain observations from both classes.", call. = FALSE)
  }
  invisible(TRUE)
}

.validate_domains <- function(x, y) {
  if (!is.list(x) || !is.list(y) || length(x) != length(y)) {
    stop("x and y must be lists of equal length.", call. = FALSE)
  }
  if (length(x) < 2L) {
    stop("At least one source and one target domain are required.", call. = FALSE)
  }
  for (k in seq_along(x)) {
    .validate_xy(x[[k]], y[[k]], paste0("domain ", k))
  }
  dimensions <- vapply(x, ncol, integer(1))
  if (length(unique(dimensions)) != 1L) {
    stop("All domains must have the same number of variables.", call. = FALSE)
  }
  invisible(TRUE)
}

.cv_part <- function(n, folds) {
  indices <- sample(seq_len(n))
  fold_id <- split(indices, rep(seq_len(folds), length.out = n))
  test <- fold_id
  train <- lapply(test, function(id) setdiff(seq_len(n), id))
  list(train = train, test = test)
}

.balanced_cv_part <- function(y, folds, max_attempts = 100L) {
  if (folds < 2L || folds > length(y)) {
    stop("folds must be between 2 and the sample size.", call. = FALSE)
  }
  for (attempt in seq_len(max_attempts)) {
    part <- .cv_part(length(y), folds)
    valid <- vapply(seq_len(folds), function(j) {
      test_y <- y[part$test[[j]]]
      train_y <- y[part$train[[j]]]
      all(tabulate(test_y + 1L, nbins = 2L) >= 2L) &&
        all(tabulate(train_y + 1L, nbins = 2L) >= 2L)
    }, logical(1))
    if (all(valid)) return(part)
  }
  stop("Unable to construct class-balanced CV folds.", call. = FALSE)
}

.cv_criterion <- function(x, y, beta) {
  x1 <- x[y == 1, , drop = FALSE]
  x0 <- x[y == 0, , drop = FALSE]
  n1 <- nrow(x1)
  n0 <- nrow(x0)
  delta <- colMeans(x0) - colMeans(x1)
  sigma <- ((n1 - 1) * stats::cov(x1) +
    (n0 - 1) * stats::cov(x0)) / (n1 + n0 - 2)
  as.numeric(crossprod(beta, sigma %*% beta) - 2 * crossprod(delta, beta))
}

.stabilize_sigma <- function(sigma) {
  p <- ncol(sigma)
  sigma <- (sigma + t(sigma)) / 2
  eig <- Re(eigen(sigma, only.values = TRUE)$values)
  perturb <- max(max(eig) - p * min(eig), 0) / (p - 1)
  sigma + diag(p) * perturb
}

.compute_one <- function(x, y) {
  x1 <- x[y == 1, , drop = FALSE]
  x0 <- x[y == 0, , drop = FALSE]
  n1 <- nrow(x1)
  n0 <- nrow(x0)
  mu1 <- colMeans(x1)
  mu0 <- colMeans(x0)
  x1c <- sweep(x1, 2, mu1, "-")
  x0c <- sweep(x0, 2, mu0, "-")
  sigma <- (crossprod(x1c) + crossprod(x0c)) / (n1 + n0 - 2)
  list(
    sigma = .stabilize_sigma(sigma),
    delta = mu0 - mu1,
    center = (mu0 + mu1) / 2,
    means = list(class1 = mu1, class0 = mu0),
    n = c(class1 = n1, class0 = n0)
  )
}

.compute_stats <- function(x, y) {
  .validate_domains(x, y)
  one <- Map(.compute_one, x, y)
  list(
    sigma = lapply(one, `[[`, "sigma"),
    delta = lapply(one, `[[`, "delta"),
    center = lapply(one, `[[`, "center"),
    means = lapply(one, `[[`, "means"),
    n = do.call(rbind, lapply(one, `[[`, "n"))
  )
}
