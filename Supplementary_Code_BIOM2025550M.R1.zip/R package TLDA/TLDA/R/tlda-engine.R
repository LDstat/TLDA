.make_sigma_tilde <- function(sigma, rho) {
  k <- length(sigma)
  p <- ncol(sigma[[1]])
  out <- vector("list", k)
  for (domain in seq_len(k - 1L)) {
    out[[domain]] <- sigma[[domain]] + rho * diag(p)
  }
  out[[k]] <- sigma[[k]] + rho * (k - 1L) * diag(p)
  out
}

.tlda_objective <- function(sigma, delta, beta, zeta,
                            lambda1, lambdaT, tau) {
  value <- 0
  for (k in seq_along(sigma)) {
    bk <- beta[k, ]
    value <- value +
      as.numeric(0.5 * crossprod(bk, sigma[[k]] %*% bk)) -
      as.numeric(crossprod(bk, delta[[k]])) +
      lambda1 * sum(abs(bk))
  }
  value + lambdaT * sum(pmin(tau, rowSums(abs(zeta))))
}

.relative_change_ok <- function(updated, previous, tolerance) {
  denominator <- norm(previous, "F")
  change <- norm(updated - previous, "F")
  if (denominator > 0) change <- change / denominator
  change <= tolerance
}

.soft_threshold <- function(level, value) {
  pmax(abs(value) - level, 0) * sign(value)
}

.update_source_beta <- function(sigma_tilde, delta, beta0, zeta, dual,
                                beta_start, lambda1, rho) {
  number_sources <- nrow(beta_start)
  p <- ncol(beta_start)
  beta <- matrix(0, number_sources, p)
  for (k in seq_len(number_sources)) {
    adjusted_delta <- as.numeric(delta[[k]]) -
      rho * as.numeric(zeta[k, ] - beta0 + dual[k, ])
    fit <- lasso_covariance_rcpp(
      XX = sigma_tilde[[k]],
      Xy = adjusted_delta,
      beta_start = as.numeric(beta_start[k, ]),
      lambda = lambda1,
      maxIter = 500L,
      optTol = 1e-4,
      zeroThreshold = 1e-4
    )
    beta[k, ] <- as.numeric(fit$coefficients)
  }
  beta
}

.update_target_beta <- function(sigma_tilde, delta, beta, zeta, dual,
                                beta_start, lambda1, rho) {
  target <- nrow(beta)
  adjusted_delta <- as.numeric(delta[[target]]) +
    rho * colSums(zeta + beta[seq_len(target - 1L), , drop = FALSE] + dual)
  fit <- lasso_covariance_rcpp(
    XX = sigma_tilde[[target]],
    Xy = adjusted_delta,
    beta_start = as.numeric(beta_start),
    lambda = lambda1,
    maxIter = 500L,
    optTol = 1e-4,
    zeroThreshold = 1e-4
  )
  as.numeric(fit$coefficients)
}

.update_contrasts <- function(beta, previous_zeta, dual,
                              lambdaT, tau, rho) {
  target <- nrow(beta)
  p <- ncol(beta)
  source <- seq_len(target - 1L)
  threshold_argument <- matrix(beta[target, ], target - 1L, p, byrow = TRUE) -
    beta[source, , drop = FALSE] - dual
  zeta <- matrix(0, target - 1L, p)
  previous_norm <- rowSums(abs(previous_zeta))
  for (k in source) {
    if (previous_norm[k] < tau) {
      zeta[k, ] <- .soft_threshold(lambdaT / rho, threshold_argument[k, ])
    } else {
      zeta[k, ] <- threshold_argument[k, ]
    }
  }
  zeta
}

.admm_fit <- function(sigma_tilde, delta, beta, zeta, dual, previous_zeta,
                      lambda1, lambdaT, tau, rho, tolerance, max_iterations) {
  target <- nrow(beta)
  p <- ncol(beta)
  source <- seq_len(target - 1L)
  primal_norm <- Inf
  for (iteration in seq_len(max_iterations)) {
    old_beta <- beta
    beta[source, ] <- .update_source_beta(
      sigma_tilde, delta, beta[target, ], zeta, dual,
      beta[source, , drop = FALSE], lambda1, rho
    )
    beta[target, ] <- .update_target_beta(
      sigma_tilde, delta, beta, zeta, dual,
      beta[target, ], lambda1, rho
    )
    zeta_new <- .update_contrasts(
      beta, previous_zeta, dual, lambdaT, tau, rho
    )
    target_matrix <- matrix(beta[target, ], target - 1L, p, byrow = TRUE)
    residual <- zeta_new - target_matrix + beta[source, , drop = FALSE]
    dual_new <- dual + residual
    primal_norm <- norm(residual, "F") / sqrt((target - 1L) * p)
    converged <- .relative_change_ok(beta, old_beta, tolerance) &&
      primal_norm <= tolerance
    zeta <- zeta_new
    dual <- dual_new
    if (converged) {
      return(list(
        beta = beta, zeta = zeta, dual = dual,
        iterations = iteration, primal_norm = primal_norm,
        converged = TRUE
      ))
    }
  }
  list(
    beta = beta, zeta = zeta, dual = dual,
    iterations = max_iterations, primal_norm = primal_norm,
    converged = FALSE
  )
}

.tlda_engine <- function(stats, beta_init, lambda1, lambdaT, tau, rho,
                         control, verbose = FALSE) {
  k <- length(stats$sigma)
  p <- ncol(stats$sigma[[1]])
  sigma_tilde <- .make_sigma_tilde(stats$sigma, rho)
  zeta <- matrix(0, k - 1L, p)
  for (source in seq_len(k - 1L)) {
    zeta[source, ] <- beta_init[k, ] - beta_init[source, ]
  }
  previous_zeta <- zeta
  dual <- matrix(0, k - 1L, p)
  beta <- beta_init
  old_loss <- .tlda_objective(
    stats$sigma, stats$delta, beta, zeta, lambda1, lambdaT, tau
  )
  admm <- NULL
  mm_iterations <- 0L
  for (iteration in seq_len(control$maxit_mm)) {
    admm <- .admm_fit(
      sigma_tilde, stats$delta, beta, zeta, dual, previous_zeta,
      lambda1, lambdaT, tau, rho,
      control$tol_admm, control$maxit_admm
    )
    beta <- admm$beta
    zeta <- admm$zeta
    dual <- admm$dual
    previous_zeta <- zeta
    new_loss <- .tlda_objective(
      stats$sigma, stats$delta, beta, zeta, lambda1, lambdaT, tau
    )
    relative_loss_change <- abs(new_loss - old_loss) / (1 + abs(old_loss))
    old_loss <- new_loss
    mm_iterations <- iteration
    if (verbose) {
      message(
        "MM iteration ", iteration,
        "; ADMM iterations ", admm$iterations,
        "; ADMM converged: ", admm$converged
      )
    }
    if (relative_loss_change < control$tol_mm) break
  }
  list(
    beta = beta,
    zeta = zeta,
    objective = old_loss,
    mm_iterations = mm_iterations,
    admm_iterations = admm$iterations,
    admm_converged = admm$converged,
    primal_norm = admm$primal_norm
  )
}
