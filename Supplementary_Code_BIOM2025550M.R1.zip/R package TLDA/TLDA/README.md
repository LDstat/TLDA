# TLDA

`TLDA` implements transfer-enhanced linear discriminant analysis for
high-dimensional binary classification with a target domain and multiple
source domains. Non-oracle TLDA uses a truncated contrast penalty to identify
transferable source domains.

## Installation

Install the source package from the directory containing the tarball:

```r
install.packages("TLDA_0.2.0.tar.gz", repos = NULL, type = "source")
```

Because the package contains C++ code, a working compilation toolchain is
required when installing from source. On Windows, install the Rtools version
corresponding to the installed R version.

## Data convention

Multi-domain inputs are lists of numeric matrices and binary label vectors.
Source domains appear first and the target domain must be the final list
element. Labels must be coded as `0` and `1`.

## Main workflow

```r
library(TLDA)

initial <- initialize_lpd(x_list, y_list, folds = 5)
lambda1_grid <- seq(0.5, 2, length.out = 5) * mean(initial$lambda)
lambdaT <- 10 * mean(initial$lambda)

cv <- cv_tlda(
  x_list,
  y_list,
  beta_init = initial$coefficients,
  lambda1 = lambda1_grid,
  lambdaT = lambdaT,
  rho = 10,
  folds = 5
)

fit <- tlda(
  x_list,
  y_list,
  beta_init = initial$coefficients,
  lambda1 = cv$lambda1,
  lambdaT = lambdaT,
  tau = cv$tau,
  rho = 10
)
```

The full Scenario 1 reproduction scripts are distributed separately with the
supplementary code.
