// [[Rcpp::depends(RcppEigen)]]
#include <RcppEigen.h>
using namespace Rcpp;
using namespace Eigen;

// [[Rcpp::export]]
NumericVector linprogPD_rcpp(NumericVector x0_,
                             NumericMatrix A_,
                             NumericVector b_,
                             double epsilon,
                             double pdtol = 1e-3,
                             int pdmaxiter = 50) {
  
  const int N = x0_.size();
  
  Map<VectorXd> x0(as<Map<VectorXd> >(x0_));
  Map<MatrixXd> A(as<Map<MatrixXd> >(A_));
  Map<VectorXd> b(as<Map<VectorXd> >(b_));
  
  double alpha = 0.01;
  double beta_bt = 0.5;
  double mu = 10.0;
  
  VectorXd gradf0(2 * N);
  gradf0.head(N).setZero();
  gradf0.tail(N).setOnes();
  
  VectorXd Ax0_minus_b = A * x0 - b;
  if (Ax0_minus_b.cwiseAbs().maxCoeff() > epsilon) {
    stop("Infeasible starting point!");
  }
  
  VectorXd x = x0;
  double max_abs_x0 = x0.cwiseAbs().maxCoeff();
  VectorXd u = 0.95 * x0.cwiseAbs().array() + 0.1 * max_abs_x0;
  
  VectorXd Atr = Ax0_minus_b;
  
  VectorXd fu1 = x - u;
  VectorXd fu2 = -x - u;
  VectorXd fe1 = Atr.array() - epsilon;
  VectorXd fe2 = -Atr.array() - epsilon;
  
  VectorXd lamu1 = -fu1.cwiseInverse();
  VectorXd lamu2 = -fu2.cwiseInverse();
  VectorXd lame1 = -fe1.cwiseInverse();
  VectorXd lame2 = -fe2.cwiseInverse();
  
  VectorXd AtAv = A.transpose() * (lame1 - lame2);
  
  double sdg = -(
    fu1.dot(lamu1) + fu2.dot(lamu2) +
      fe1.dot(lame1) + fe2.dot(lame2)
  );
  
  double tau = mu * (4.0 * N) / sdg;
  
  VectorXd rdual(2 * N);
  rdual.head(N) = lamu1 - lamu2 + AtAv;
  rdual.tail(N) = -lamu1 - lamu2;
  rdual += gradf0;
  
  VectorXd rcent(4 * N);
  rcent.segment(0, N) = lamu1.cwiseProduct(fu1);
  rcent.segment(N, N) = lamu2.cwiseProduct(fu2);
  rcent.segment(2 * N, N) = lame1.cwiseProduct(fe1);
  rcent.segment(3 * N, N) = lame2.cwiseProduct(fe2);
  rcent = -rcent.array() - 1.0 / tau;
  
  double resnorm = std::sqrt(rdual.squaredNorm() + rcent.squaredNorm());
  
  int pditer = 0;
  bool done = (sdg < pdtol) || (pditer >= pdmaxiter);
  
  VectorXd xp = x;
  
  while (!done) {
    
    VectorXd inv_fu1 = fu1.cwiseInverse();
    VectorXd inv_fu2 = fu2.cwiseInverse();
    VectorXd inv_fe1 = fe1.cwiseInverse();
    VectorXd inv_fe2 = fe2.cwiseInverse();
    
    VectorXd w2 = -VectorXd::Ones(N) - (inv_fu1 + inv_fu2) / tau;
    
    VectorXd sig11 = -lamu1.cwiseProduct(inv_fu1) - lamu2.cwiseProduct(inv_fu2);
    VectorXd sig12 =  lamu1.cwiseProduct(inv_fu1) - lamu2.cwiseProduct(inv_fu2);
    VectorXd siga  = -lame1.cwiseProduct(inv_fe1) - lame2.cwiseProduct(inv_fe2);
    VectorXd sigx  = sig11 - sig12.cwiseProduct(sig12).cwiseQuotient(sig11);
    
    if ((siga.array() <= 0).any() || !siga.allFinite()) {
      return wrap(x);
    }
    
    VectorXd w1 = -(A.transpose() * (inv_fe2 - inv_fe1) + inv_fu2 - inv_fu1) / tau;
    VectorXd w1p = w1 - sig12.cwiseQuotient(sig11).cwiseProduct(w2);
    
    MatrixXd B = A;
    for (int i = 0; i < N; ++i) {
      B.row(i) *= std::sqrt(siga(i));
    }
    
    MatrixXd Hp = B.transpose() * B;
    Hp.diagonal() += sigx;
    
    Eigen::LLT<MatrixXd> llt(Hp);
    if (llt.info() != Success) {
      return wrap(x);
    }
    
    VectorXd dx = llt.solve(w1p);
    VectorXd AtAdx = A * dx;
    
    VectorXd du = w2.cwiseQuotient(sig11)
      - sig12.cwiseQuotient(sig11).cwiseProduct(dx);
    
    VectorXd dlamu1 =
      -lamu1.cwiseQuotient(fu1).cwiseProduct(dx - du)
      - lamu1 - (fu1 * tau).cwiseInverse();
    
    VectorXd dlamu2 =
      -lamu2.cwiseQuotient(fu2).cwiseProduct(-dx - du)
      - lamu2 - (fu2 * tau).cwiseInverse();
    
    VectorXd dlame1 =
      -lame1.cwiseQuotient(fe1).cwiseProduct(AtAdx)
      - lame1 - (fe1 * tau).cwiseInverse();
    
    VectorXd dlame2 =
      lame2.cwiseQuotient(fe2).cwiseProduct(AtAdx)
      - lame2 - (fe2 * tau).cwiseInverse();
    
    VectorXd AtAdv = A.transpose() * (dlame1 - dlame2);
    
    double smax = 1.0;
    
    auto update_smax = [&](double val) {
      if (std::isfinite(val) && val > 0 && val < smax) smax = val;
    };
    
    for (int i = 0; i < N; ++i) {
      if (dlamu1(i) < 0) update_smax(-lamu1(i) / dlamu1(i));
      if (dlamu2(i) < 0) update_smax(-lamu2(i) / dlamu2(i));
      if (dlame1(i) < 0) update_smax(-lame1(i) / dlame1(i));
      if (dlame2(i) < 0) update_smax(-lame2(i) / dlame2(i));
      
      if ((dx(i) - du(i)) > 0) update_smax(-fu1(i) / (dx(i) - du(i)));
      if ((-dx(i) - du(i)) > 0) update_smax(-fu2(i) / (-dx(i) - du(i)));
      
      if (AtAdx(i) > 0) update_smax(-fe1(i) / AtAdx(i));
      if (AtAdx(i) < 0) update_smax(-fe2(i) / (-AtAdx(i)));
    }
    
    double step = 0.99 * smax;
    
    bool suffdec = false;
    int backiter = 0;
    
    VectorXd up, Atrp, AtAvp;
    VectorXd fu1p, fu2p, fe1p, fe2p;
    VectorXd lamu1p, lamu2p, lame1p, lame2p;
    VectorXd rdp(2 * N), rcp(4 * N);
    
    while (!suffdec) {
      xp = x + step * dx;
      up = u + step * du;
      Atrp = Atr + step * AtAdx;
      AtAvp = AtAv + step * AtAdv;
      
      fu1p = fu1 + step * (dx - du);
      fu2p = fu2 + step * (-dx - du);
      fe1p = fe1 + step * AtAdx;
      fe2p = fe2 + step * (-AtAdx);
      
      lamu1p = lamu1 + step * dlamu1;
      lamu2p = lamu2 + step * dlamu2;
      lame1p = lame1 + step * dlame1;
      lame2p = lame2 + step * dlame2;
      
      rdp.head(N) = lamu1p - lamu2p + AtAvp;
      rdp.tail(N) = -lamu1p - lamu2p;
      rdp += gradf0;
      
      rcp.segment(0, N) = lamu1p.cwiseProduct(fu1p);
      rcp.segment(N, N) = lamu2p.cwiseProduct(fu2p);
      rcp.segment(2 * N, N) = lame1p.cwiseProduct(fe1p);
      rcp.segment(3 * N, N) = lame2p.cwiseProduct(fe2p);
      rcp = -rcp.array() - 1.0 / tau;
      
      suffdec =
        std::sqrt(rdp.squaredNorm() + rcp.squaredNorm())
        < (1.0 - alpha * step) * resnorm;
      
      step *= beta_bt;
      backiter++;
      
      if (backiter > 32) {
        return wrap(x);
      }
    }
    
    x = xp;
    u = up;
    Atr = Atrp;
    AtAv = AtAvp;
    
    fu1 = fu1p;
    fu2 = fu2p;
    fe1 = fe1p;
    fe2 = fe2p;
    
    lamu1 = lamu1p;
    lamu2 = lamu2p;
    lame1 = lame1p;
    lame2 = lame2p;
    
    sdg = -(
      fu1.dot(lamu1) + fu2.dot(lamu2) +
        fe1.dot(lame1) + fe2.dot(lame2)
    );
    
    tau = mu * (4.0 * N) / sdg;
    rdual = rdp;
    
    rcent.segment(0, N) = fu1.cwiseProduct(lamu1);
    rcent.segment(N, N) = fu2.cwiseProduct(lamu2);
    rcent.segment(2 * N, N) = fe1.cwiseProduct(lame1);
    rcent.segment(3 * N, N) = fe2.cwiseProduct(lame2);
    rcent = -rcent.array() - 1.0 / tau;
    
    resnorm = std::sqrt(rdual.squaredNorm() + rcent.squaredNorm());
    
    pditer++;
    done = (sdg < pdtol) || (pditer >= pdmaxiter);
  }
  
  return wrap(xp);
}