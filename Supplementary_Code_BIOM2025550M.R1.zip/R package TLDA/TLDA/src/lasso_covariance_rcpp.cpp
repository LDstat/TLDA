// [[Rcpp::depends(RcppEigen)]]
#include <RcppEigen.h>

using namespace Rcpp;
using namespace Eigen;

// [[Rcpp::export]]
List lasso_covariance_rcpp(const Eigen::Map<Eigen::MatrixXd> XX,
                           const Eigen::Map<Eigen::VectorXd> Xy,
                           Eigen::Map<Eigen::VectorXd> beta_start,
                           double lambda,
                           int maxIter = 500,
                           double optTol = 1e-4,
                           double zeroThreshold = 1e-4) {
  /*
   Solve:
      min_beta  1/2 beta^T XX beta - Xy^T beta + lambda ||beta||_1
   by cyclic coordinate descent.
  */
  
  int p = Xy.size();
  
  VectorXd beta = beta_start;
  VectorXd s = XX * beta;  // s = XX %*% beta
  VectorXd diagXX = XX.diagonal();
  
  for (int j = 0; j < p; ++j) {
    if (diagXX(j) <= 0.0 || !std::isfinite(diagXX(j))) {
      stop("All diagonal entries of XX must be positive and finite.");
    }
  }
  
  int iter = 0;
  
  for (iter = 0; iter < maxIter; ++iter) {
    VectorXd beta_old = beta;
    
    for (int j = 0; j < p; ++j) {
      // S0 = s[j] - XX[j,j] * beta[j] - Xy[j]
      double S0 = s(j) - diagXX(j) * beta(j) - Xy(j);
      
      double beta_new_j = 0.0;
      
      if (!std::isfinite(S0)) {
        beta_new_j = 0.0;
      } else if (S0 > lambda) {
        beta_new_j = (lambda - S0) / diagXX(j);
      } else if (S0 < -lambda) {
        beta_new_j = (-lambda - S0) / diagXX(j);
      } else {
        beta_new_j = 0.0;
      }
      
      double diff_j = beta_new_j - beta(j);
      
      if (diff_j != 0.0) {
        beta(j) = beta_new_j;
        // s = s + XX[, j] * diff_j
        s.noalias() += XX.col(j) * diff_j;
      }
    }
    
    double diff_norm = (beta - beta_old).cwiseAbs().sum();
    
    if (diff_norm < optTol) {
      break;
    }
  }
  
  for (int j = 0; j < p; ++j) {
    if (std::abs(beta(j)) < zeroThreshold) {
      beta(j) = 0.0;
    }
  }
  
  return List::create(
    Named("coefficients") = beta,
    Named("num.it") = iter + 1
  );
}