﻿# TLDA R Package

This directory contains version 0.2.0 of the `TLDA` R package for
transfer-enhanced linear discriminant analysis.

## Files

- `TLDA_0.2.0.tar.gz`: source package for installation.
- `TLDA.pdf`: reference manual for the public functions.
- `TLDA/`: package source code. This directory is included for inspection;
  installation from the tarball is recommended.

## Installation in R

Installation from source requires R 4.1.0 or later and a working C++
toolchain (for example, the corresponding version of Rtools on Windows).

Start R in this directory and install the required R packages if they are not
already available:

```r
install.packages(c("MASS", "Rcpp", "RcppEigen"))
```

Install `TLDA` from the supplied source package:

```r
install.packages(
  "TLDA_0.2.0.tar.gz",
  repos = NULL,
  type = "source"
)
```

Alternatively, installation can be run from a terminal:

```bash
R CMD INSTALL TLDA_0.2.0.tar.gz
```

## Verification

Load the package and confirm its version:

```r
library(TLDA)
packageVersion("TLDA")
```

The reported version should be `0.2.0`. Function usage and argument
descriptions are provided in `TLDA.pdf` and through the usual R help system,
for example:

```r
help(package = "TLDA")
?cv_tlda
?tlda
```

The companion directory `simulation study for S1` contains the code for
reproducing Scenario 1 and can install this package into its own local R
library automatically.
