Sys.setenv(
  "OMP_NUM_THREADS" = "1",
  "OPENBLAS_NUM_THREADS" = "1",
  "MKL_NUM_THREADS" = "1"
)
library(RhpcBLASctl)
blas_set_num_threads(1)
omp_set_num_threads(1)

print(paste("OMP_NUM_THREADS =", Sys.getenv("OMP_NUM_THREADS")))
print(paste("BLAS threads =", RhpcBLASctl::blas_get_num_procs()))


rm(list = ls())
library("MASS")
source("DC-ADMM functions.R")
source("DGP.R")
source("one_round.R")
library(Rcpp)
library(RcppEigen)
t1=proc.time()
seed=0918
set.seed(seed)

iteration=100
core_number =50

A_num_grid = c(0,1,2,3,4,5)
# A_num_grid = c(1,3,5)
K=6
p=400;nt=100;ns=200
nk <- c(rep(ns, K - 1), nt)

# DGP parameters
s <- 20
ntest <- 200

# covariance parameters
sig <- 0.5          # AR(1) covariance correlation parameter
heter_cov <- 0.5   # covariance perturbation strength

# target beta parameters
beta_low <- 1
beta_high <- 2
signal_norm <- sqrt(s)
normalize <- TRUE

# informative source: same support, same signs, mild magnitude perturbation
inf_mismatch_prop <- 0.5
inf_perturb_sd <- 0.5


# non-informative source: low support overlap + partial sign flip + source-specific signals
non_overlap_prop <- 0.5
non_perturb_sd <- 0.5

non_extra_scale <- 1



non_flip_prob <- 0.7
inf_extra_low <- 1
inf_extra_high <- 2



cat(paste0(
  "\n========== DGP SETTINGS ==========\n",
  "K=", K,
  "; p=", p,
  "; nt=", nt,
  "; ns=", ns,
  "\n",
  
  "s=", s,
  "; ntest=", ntest,
  "\n",
  
  "COVARIANCE: ",
  "sig=", sig,
  "; heter_cov=", heter_cov,
  "\n",
  
  "TARGET BETA: ",
  "beta_low=", beta_low,
  "; beta_high=", beta_high,
  "; signal_norm=", round(signal_norm, 4),
  "; normalize=", normalize,
  "\n",
  
  "INFORMATIVE SOURCE: ",
  "inf_perturb_sd=", inf_perturb_sd,
  "; inf_mismatch_prop=", inf_mismatch_prop,
  "; inf_extra_low=", inf_extra_low,
  "; inf_extra_high=", inf_extra_high,
  "\n",
  
  "NON-INFORMATIVE SOURCE: ",
  "non_perturb_sd=", non_perturb_sd,
  "; non_overlap_prop=", non_overlap_prop,
  "; non_flip_prob=", non_flip_prob,
  "; non_extra_scale=", non_extra_scale,
  "\n",
  "==================================\n"
))




# tunning parameters
fold=5
lam_min = 0.5;lam_max = 5;nlam =10 # LPD
lam1_tlp_min = 0.5;lam1_tlp_max = 2;lam1_tlp_nlam = 5 # TLP lam1
rho_tlp = 10 # step size in ADMM
maxit_MM_tlp = 2 # MM
maxit_admm_tlp = 1000


# =====================================================
# Fixed target and fixed source candidate pool
# =====================================================

# 1. fixed target beta
beta0_fixed <- generate_beta0_random(
  p = p,
  s = s,
  low = beta_low,
  high = beta_high,
  signal_norm = signal_norm,
  normalize = normalize
)

# 2. fixed target covariance
sigma0_fixed <- sig^abs(outer(1:p, 1:p, "-"))
#sigma0_fixed = diag(p)
# 3. fixed source covariance matrices
sigma_pool <- vector("list", K)
sigma_pool[[K]] <- sigma0_fixed

for (k in 1:(K - 1)) {
  epsilon <- rnorm(p, mean = 0, sd = heter_cov)
  sigma_pool[[k]] <- sigma0_fixed + tcrossprod(epsilon)
}

# 4. fixed informative and non-informative beta versions for each source
beta_inf_pool <- matrix(0, nrow = K - 1, ncol = p)
beta_non_pool <- matrix(0, nrow = K - 1, ncol = p)

for (k in 1:(K - 1)) {
  beta_inf_pool[k, ] <- generate_betak_informative(
    beta0 = beta0_fixed,
    perturb_sd = inf_perturb_sd,
    mismatch_prop = inf_mismatch_prop,
    extra_low = inf_extra_low,
    extra_high = inf_extra_high
  )
  
  beta_non_pool[k, ] <- generate_betak_noninformative(
    beta0 = beta0_fixed,
    overlap_prop = non_overlap_prop,
    flip_prob = non_flip_prob,
    perturb_sd = non_perturb_sd,
    magnitude_low = beta_low,
    magnitude_high = beta_high,
    extra_scale = non_extra_scale
  )
}




library(doParallel);library(parallel);library(foreach);library(doRNG)
cl <- makeCluster(core_number)
registerDoParallel(cl)

invisible(clusterEvalQ(cl, {
  library(MASS)
  library(Rcpp)
  library(RcppEigen)
  source("DC-ADMM functions.R")
  source("DGP.R")
  source("one_round.R")
  Rcpp::sourceCpp("linprogPD_rcpp.cpp")
  Rcpp::sourceCpp("lasso_covariance_rcpp.cpp")
  NULL
}))

all_results <- vector("list", length(A_num_grid))
names(all_results) <- paste0("A_num_", A_num_grid)
for (A_num in A_num_grid){
  # A_num = A_num_grid[2]
  cat("\n\n=====================================\n")
  cat("Running A_num =", A_num, "\n")
  cat("=====================================\n")
  
  # =======================================
  # generate parameter
  # =======================================
  para <- DGP_beta_fixed_target(
    K = K,
    A_num = A_num,
    beta0_fixed = beta0_fixed,
    sigma_pool = sigma_pool,
    beta_inf_pool = beta_inf_pool,
    beta_non_pool = beta_non_pool,
    A_source_mode = "nested"
  )
  
  
  beta_target = para$beta
  sigma_target = para$sigma
  inf_set = para$A_source
  not_inf = para$not_inf
  true_A = para$true_A
  cat("target beta norm =", round(sqrt(sum(beta_target[K, ]^2)), 4), "\n")
  beta_diff_l1 <- sapply(1:(K - 1), function(k) {
    sum(abs(beta_target[k, ] - beta_target[K, ]))
  })
  
  cat("source-target beta l1 distance =", round(beta_diff_l1, 4), "\n")
  
  
  Delta_target <- sqrt(
    as.numeric(beta_target[K, ] %*% sigma_target[[K]] %*% beta_target[K, ])
  )
  R_opt_target <- pnorm(- Delta_target / 2)
  cat("Bayes mis error =", round(R_opt_target, 4), "\n")
  cat("true_A =", true_A, "\n")
  
  # =======================================
  # parallel start
  # =======================================
  
  
  
  res_list <- foreach(
    x = 1:iteration,
    .packages = c("MASS", "Rcpp", "RcppEigen"),
    .errorhandling = "pass",
    .noexport = c(
      "one_run",
      "linprogPD_rcpp",
      "lasso_covariance_rcpp"
    )
  ) %dorng% {
    one_round()
  }
  
  ok <- sapply(res_list, function(z) !inherits(z, "error"))
  res_ok <- res_list[ok]
  
  cat("success iteration =", length(res_ok), "\n")
  # vector
  lambdaopt <- sapply(res_ok, `[[`, "lambda1opt")
  tauopt <- sapply(res_ok, `[[`, "tauopt")
  # matrix
  lambda_grid = do.call(rbind, lapply(res_ok, `[[`, "lambda1"))
  tau_grid = do.call(rbind, lapply(res_ok, `[[`, "tau_grid"))
  contr = do.call(rbind, lapply(res_ok, `[[`, "contr"))
  best_tunning = do.call(rbind, lapply(res_ok, `[[`, "best_lam1tau"))
  norm_re <- do.call(rbind, lapply(res_ok, `[[`, "norm_re"))
norm_weighted <- do.call(rbind, lapply(res_ok, `[[`, "norm_weighted"))
  mis <- do.call(rbind, lapply(res_ok, `[[`, "mis"))
  hat_true_A <- do.call(rbind, lapply(res_ok, `[[`, "hat_true_A"))
  # list
  beta_re_list <- lapply(res_ok, `[[`, "beta_re")
  beta_all_lpd_list <- lapply(res_ok, `[[`, "beta_all_lpd")
  beta_tlp_list <- lapply(res_ok, `[[`, "beta_tlp")
  loss.mean.tar_list <- lapply(res_ok, `[[`, "loss.mean.tar")
  
  # =======================================
  # print result
  # =======================================
  norm_mean <- apply(norm_re, 2, mean)
  norm_sd = apply(norm_re, 2, sd)
  norm_weighted_mean <- apply(norm_weighted, 2, mean)
  norm_weighted_sd = apply(norm_weighted, 2, sd)
  mis_mean <- apply(mis, 2, mean)
  mis_sd = apply(mis, 2, sd)  
  hat_A_sum <- apply(hat_true_A, 2, sum)
  cat(" =========== norm_re ===========", "\n")
  print(norm_mean)
  cat(" =========== norm_weighted ===========", "\n")
  print(norm_weighted_mean)
  cat(" =========== mis error ===========", "\n")
  print(mis_mean)
  cat(" =========== hat_true_A ===========", "\n")
  print(hat_A_sum)
  
  
  all_results[[paste0("A_num_", A_num)]] <- list(
    A_num = A_num,
    true_A = true_A,
    inf_set = inf_set,
    not_inf = not_inf,
    R_opt_target = R_opt_target,
    
    success = length(res_ok),
    ok = ok,
    
    lambdaopt = lambdaopt,
    tauopt = tauopt,
    lambda_grid = lambda_grid,
    tau_grid = tau_grid,
    contr = contr,
    best_tunning = best_tunning,
    
    norm_re = norm_re,
    norm_weighted = norm_weighted,
    mis = mis,
    hat_true_A = hat_true_A,
    
    norm_mean = norm_mean,
    norm_sd = norm_sd,
    norm_weighted_mean = norm_weighted_mean,
    norm_weighted_sd = norm_weighted_sd,
    mis_mean = mis_mean,
    mis_sd = mis_sd,
    hat_A_sum = hat_A_sum,
    
    beta_re_list = beta_re_list,
    beta_all_lpd_list = beta_all_lpd_list,
    beta_tlp_list = beta_tlp_list,
    loss.mean.tar_list = loss.mean.tar_list,
    
    res_raw = res_list
  )
  
  #save.image(file = save_name)  
}

stopCluster(cl)

# =======================================
# parallel end
# =======================================



norm_summary <- do.call(rbind, lapply(A_num_grid, function(a) {
  all_results[[paste0("A_num_", a)]]$norm_mean
}))

norm_weighted_summary <- do.call(rbind, lapply(A_num_grid, function(a) {
  all_results[[paste0("A_num_", a)]]$norm_weighted_mean
}))

mis_summary <- do.call(rbind, lapply(A_num_grid, function(a) {
  all_results[[paste0("A_num_", a)]]$mis_mean
}))

rownames(norm_summary) <- paste0("A_num=", A_num_grid)
rownames(norm_weighted_summary) <- paste0("A_num=", A_num_grid)
rownames(mis_summary)  <- paste0("A_num=", A_num_grid)

cat("\n=========== Final norm summary ===========\n")
print(round(norm_summary, 4))

cat("\n=========== Final norm_weighted summary ===========\n")
print(round(norm_weighted_summary, 4))

cat("\n=========== Final mis summary ===========\n")
print(round(mis_summary, 4))




#save.image(file = save_name)



t2=proc.time()
print(paste0('running_time:',(t2-t1)[3][[1]],'s'))
