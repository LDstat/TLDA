#------------------ compute misclassification error------------------------
out_mis = function(a,ind_a,hatbeta){
  u1 = apply(a[ind_a==1,],2,mean)
  u2 = apply(a[ind_a!=1,],2,mean)
  u12 = (u1+u2)/2
  a_row = nrow(a)
  matrix_u12 = matrix(rep(u12, times = a_row), nrow = a_row, byrow = TRUE)
  predict.u=(a- matrix_u12)%*% hatbeta
  predict.u[predict.u>0]=0
  predict.u[predict.u<0]=1
  mis= sum(predict.u!=ind_a)/a_row
  return(mis)
}





cv.part <- function(n, fold) {
  ind <- sample(seq_len(n))
  fold_id <- split(ind, rep(seq_len(fold), length.out = n))
  
  trainList <- vector("list", fold)
  testList <- vector("list", fold)
  
  for (j in seq_len(fold)) {
    test_idx <- fold_id[[j]]
    train_idx <- setdiff(seq_len(n), test_idx)
    
    testList[[j]] <- test_idx
    trainList[[j]] <- train_idx
  }
  
  return(list(trainMat = trainList, testMat = testList))
}


cv.part.balanced <- function(n, fold, X_ind) {
  max_attempts <- 100
  
  for (attempt in seq_len(max_attempts)) {
    result <- cv.part(n, fold)
    valid_split <- TRUE
    
    for (i in seq_len(fold)) {
      test_labels <- X_ind[result$testMat[[i]]]
      train_labels <- X_ind[result$trainMat[[i]]]
      
      test_class1 <- sum(test_labels == 1)
      test_class0 <- sum(test_labels != 1)
      
      train_class1 <- sum(train_labels == 1)
      train_class0 <- sum(train_labels != 1)
      
      if (test_class1 < 2 || test_class0 < 2 ||
          train_class1 < 2 || train_class0 < 2) {
        valid_split <- FALSE
        break
      }
    }
    
    if (valid_split) {
      return(result)
    }
  }
  
  stop("CV cannot succeed in ", max_attempts, " attempts.")
}


# ----------------- CV.criterion argmin{beta^T Sigma beta - 2delta^T beta}  ------------------
CV.criterion <- function(X, X_ind, beta_train) {
  
  x1 <- X[X_ind == 1, , drop = FALSE]
  x2 <- X[X_ind != 1, , drop = FALSE]
  nn1 <- nrow(x1)
  nn2 <- nrow(x2)
  nn <- nn1 + nn2
  
  u1 <- colMeans(x1)
  u2 <- colMeans(x2)
  diff <- u2 - u1
  
  sigmahat_CV <- ((nn1 - 1) * cov(x1) +
                    (nn2 - 1) * cov(x2)) / (nn - 2)
  
  loss <- as.numeric(
    crossprod(beta_train, sigmahat_CV %*% beta_train) -
      2 * crossprod(diff, beta_train)
  )
  return(loss)
}

CV.misclass <- function(X_test, y_test, beta_train, X_train, y_train) {
  
  x1_train <- X_train[y_train == 1, , drop = FALSE]
  x2_train <- X_train[y_train != 1, , drop = FALSE]
  
  u1_train <- colMeans(x1_train)
  u2_train <- colMeans(x2_train)
  center_train <- (u1_train + u2_train) / 2
  
  score <- as.numeric(
    (X_test - matrix(center_train, nrow(X_test), ncol(X_test), byrow = TRUE)) %*% beta_train
  )
  
  pred <- ifelse(score > 0, 0, 1)
  return(mean(pred != y_test))
}




lpd_prepare <- function(x, train) {
  n <- nrow(x)
  p <- ncol(x)
  n1 <- sum(train == 1)
  n2 <- n - n1
  
  x1 <- x[train == 1, , drop = FALSE]
  x2 <- x[train != 1, , drop = FALSE]
  
  u1hat <- colMeans(x1)
  u2hat <- colMeans(x2)
  diff <- u2hat - u1hat
  
  sigmahat <- ((n1 - 1) * cov(x1) + (n2 - 1) * cov(x2)) / (n1 + n2 - 2)
  
  eigvals <- eigen(sigmahat, only.values = TRUE)$values
  perturb <- max(max(eigvals) - p * min(eigvals), 0) / (p - 1)
  sigmahat <- sigmahat + diag(p) * perturb
  
  initial <- tryCatch(
    solve(sigmahat, diff),
    error = function(e) MASS::ginv(sigmahat) %*% diff
  )
  
  list(
    sigmahat = sigmahat,
    diff = as.vector(diff),
    initial = as.vector(initial)
  )
}





lpd_fast <- function(prep, lambda, pdtol = 1e-3, pdmaxiter = 50, x0 = NULL) {
  if (is.null(x0)) x0 <- prep$initial
  linprogPD_rcpp(
    x0 = x0,
    A = prep$sigmahat,
    b = prep$diff,
    epsilon = lambda,
    pdtol = pdtol,
    pdmaxiter = pdmaxiter
  )
}


cv.lpd.fast <- function(x, x_ind, fold, lambda = NULL,
                        lambda.min, lambda.max, nlambda,
                        pdtol = 1e-3, pdmaxiter = 50) {
  n <- nrow(x)
  p <- ncol(x)
  part.list <- cv.part.balanced(n, fold, x_ind)
  lambda_base <- sqrt(log(p) / n)
  if (is.null(lambda)) {
    c_grid <- seq(lambda.min, lambda.max, length.out = nlambda)
    lambda <- c_grid * lambda_base
  }
  
  loss.re <- matrix(0, nrow = fold, ncol = nlambda)
  
  for (j in 1:fold) {
    # j=1
    x.train <- x[part.list$trainMat[[j]], , drop = FALSE]
    indtrain <- x_ind[part.list$trainMat[[j]]]
    x.test <- x[part.list$testMat[[j]], , drop = FALSE]
    indtest <- x_ind[part.list$testMat[[j]]]
    
    prep <- lpd_prepare(x.train, indtrain)
    x0 <- prep$initial
    
    for (jl in 1:nlambda) {
      beta <- lpd_fast(prep, lambda[jl], pdtol, pdmaxiter, x0 = x0)
      loss.re[j, jl] <- CV.criterion(x.test, indtest, beta)
      x0 <- beta  # warm start
    }
  }
  
  loss.mean <- colMeans(loss.re)
  optjl <- which.min(loss.mean)
  
  outlist <- list(
    lambdaopt = lambda[optjl],
    optjl = optjl,
    lambda = lambda,
    loss.mean = loss.mean
  )
  class(outlist) <- c("cv.lpd")
  outlist
}

lpd_prepare_debias <- function(x, train, hatP) {
  n <- nrow(x)
  p <- ncol(x)
  n1 <- sum(train == 1)
  n2 <- n - n1
  
  x1 <- x[train == 1, , drop = FALSE]
  x2 <- x[train != 1, , drop = FALSE]
  
  u1hat <- colMeans(x1)
  u2hat <- colMeans(x2)
  diff <- u2hat - u1hat
  
  sigmahat <- ((n1 - 1) * cov(x1) +
                 (n2 - 1) * cov(x2)) / (n1 + n2 - 2)
  
  eigvals <- eigen(sigmahat, only.values = TRUE)$values
  perturb <- max(max(eigvals) - p * min(eigvals), 0) / (p - 1)
  sigmahat <- sigmahat + diag(p) * perturb
  
  diff_debias <- as.vector(diff - sigmahat %*% hatP)
  
  initial <- tryCatch(
    solve(sigmahat, diff_debias),
    error = function(e) MASS::ginv(sigmahat) %*% diff_debias
  )
  
  list(
    sigmahat = sigmahat,
    diff = as.vector(diff),
    diff_debias = as.vector(diff_debias),
    initial = as.vector(initial)
  )
}


lpd_fast_debias <- function(prep, lambda,
                            pdtol = 1e-3,
                            pdmaxiter = 50,
                            x0 = NULL) {
  if (is.null(x0)) x0 <- prep$initial
  
  infeas <- max(abs(prep$sigmahat %*% x0 - prep$diff_debias))
  if (infeas > lambda) {
    lambda <- 1.01 * infeas
  }
  
  linprogPD_rcpp(
    x0 = as.vector(x0),
    A = prep$sigmahat,
    b = prep$diff_debias,
    epsilon = lambda,
    pdtol = pdtol,
    pdmaxiter = pdmaxiter
  )
}



cv.lpd.debias.fast <- function(x, x_ind, hatP, fold,
                               lambda = NULL,
                               lambda.min, lambda.max, nlambda,
                               pdtol = 1e-3,
                               pdmaxiter = 50) {
  n <- nrow(x)
  p <- ncol(x)
  
  part.list <- cv.part.balanced(n, fold, x_ind)
  
  lambda_base <- sqrt(log(p) / n)
  if (is.null(lambda)) {
    c_grid <- seq(lambda.min, lambda.max, length.out = nlambda)
    lambda <- c_grid * lambda_base
  }
  
  loss.re <- matrix(0, nrow = fold, ncol = nlambda)
  
  for (j in 1:fold) {
    
    x.train <- x[part.list$trainMat[[j]], , drop = FALSE]
    indtrain <- x_ind[part.list$trainMat[[j]]]
    
    x.test <- x[part.list$testMat[[j]], , drop = FALSE]
    indtest <- x_ind[part.list$testMat[[j]]]
    
    prep <- lpd_prepare_debias(
      x = x.train,
      train = indtrain,
      hatP = hatP
    )
    
    x0 <- prep$initial
    
    for (jl in 1:nlambda) {
      
      zeta <- lpd_fast_debias(
        prep = prep,
        lambda = lambda[jl],
        pdtol = pdtol,
        pdmaxiter = pdmaxiter,
        x0 = x0
      )
      
      beta_debias <- as.vector(hatP + zeta)
      
      loss.re[j, jl] <- CV.criterion(
        X = x.test,
        X_ind = indtest,
        beta_train = beta_debias
      )
      
      x0 <- zeta
    }
  }
  
  loss.mean <- colMeans(loss.re)
  optjl <- which.min(loss.mean)
  
  outlist <- list(
    lambdaopt = lambda[optjl],
    optjl = optjl,
    lambda = lambda,
    loss.mean = loss.mean,
    loss.re = loss.re
  )
  
  class(outlist) <- "cv.lpd.debias"
  return(outlist)
}









make_sigma_tilde <- function(sigma, K, p, rho) {
  Ip <- diag(p)
  sigma_tilde <- vector("list", K)
  
  for (k in 1:(K - 1)) {
    sigma_tilde[[k]] <- sigma[[k]] + rho * Ip
  }
  
  sigma_tilde[[K]] <- sigma[[K]] + rho * (K - 1) * Ip
  
  return(sigma_tilde)
}


TLP <- function(stats,
                sigma_tilde,
                beta_int,
                K, p,lambda1, lambda2, tau, rho,maxit_MM, tol_ADMM, maxit_ADMM,
                tol_MM = 1e-4) {
  
  sigma <- stats$sigma
  delta <- stats$delta
  
  if (is.null(sigma_tilde)) {
    sigma_tilde <- make_sigma_tilde(sigma, K, p, rho)
  }
  
  zeta_int <- matrix(0, K - 1, p)
  for (k in 1:(K - 1)) {
    zeta_int[k, ] <- beta_int[K, ] - beta_int[k, ]
  }
  
  zeta_m <- zeta_int
  v_int <- matrix(0, K - 1, p)
  
  loss_old <- as.numeric(
    Loss_S(sigma, delta, beta = beta_int, zeta = zeta_int,
           K, p, lambda1, lambda2, tau)
  )
  
  beta_update <- beta_int
  zeta_update <- zeta_int
  
  for (m in seq_len(maxit_MM)) {
    
    fit <- ADMM_new(
      sigma_tilde = sigma_tilde,
      delta = delta,
      beta_ad = beta_int,
      zeta_ad = zeta_int,
      v_ad = v_int,
      zeta_m = zeta_m,
      K = K,
      p = p,
      lambda1 = lambda1,
      lambda2 = lambda2,
      tau = tau,
      rho = rho,
      tol_ADMM = tol_ADMM,
      maxit_ADMM = maxit_ADMM
    )
    cat("MM iteration =", m,
        ", ADMM l =", fit$l,
        ", converged =", fit$converged,
        "\n")
    
    beta_update <- fit$beta_new
    zeta_update <- fit$zeta_new
    
    loss_new <- as.numeric(
      Loss_S(sigma, delta, beta = beta_update, zeta = zeta_update,
             K, p, lambda1, lambda2, tau)
    )
    
    rel_change <- abs(loss_new - loss_old) / (1 + abs(loss_old))
    
    beta_int <- beta_update
    zeta_int <- zeta_update
    v_int <- fit$v_new
    zeta_m <- zeta_update
    loss_old <- loss_new
    
    if (rel_change < tol_MM) {
      break
    }
  }
  
  list(
    beta_update = beta_update,
    zeta_update = zeta_update
  )
}









cv_TLP_tau <- function(x_list, ind_list, beta_int,
                       K, p,
                       lambda1, lambda2, tau_grid,
                       rho, fold,
                       maxit_MM, tol_ADMM, maxit_ADMM,
                       tol_MM = 1e-5,
                       verbose = TRUE) {
  
  nlambda <- length(lambda1)
  ntau <- length(tau_grid)
  
  # ---------- 1. create CV splits ----------
  part.list <- vector("list", K)
  for (k in 1:K) {
    part.list[[k]] <- cv.part.balanced(
      n = nrow(x_list[[k]]),
      fold = fold,
      X_ind = ind_list[[k]]
    )
  }
  
  if (verbose) print("part.list OK")
  
  # loss[fold, lambda_index, tau_index]
  loss.re.tar <- array(NA_real_, dim = c(fold, nlambda, ntau))
  # ---------- 2. CV loop ----------
  for (j in 1:fold) {
    # j=1
    x.train <- vector("list", K)
    indtrain <- vector("list", K)
    x.test <- vector("list", K)
    indtest <- vector("list", K)
    
    for (k in 1:K) {
      train_id <- part.list[[k]]$trainMat[[j]]
      test_id  <- part.list[[k]]$testMat[[j]]
      
      x.train[[k]] <- x_list[[k]][train_id, , drop = FALSE]
      indtrain[[k]] <- ind_list[[k]][train_id]
      
      x.test[[k]] <- x_list[[k]][test_id, , drop = FALSE]
      indtest[[k]] <- ind_list[[k]][test_id]
    }
    
    stats_train <- compute_sigma_mu(x.train, indtrain)
    sigma_tilde_train <- make_sigma_tilde(stats_train$sigma, K, p, rho)
    
    for (jt in 1:ntau) {
      tau_now <- tau_grid[jt]
      
      for (jl in 1:nlambda) {
        
        out <- TLP(
          stats = stats_train,
          sigma_tilde = sigma_tilde_train,
          beta_int = beta_int,
          K = K,
          p = p,
          lambda1 = lambda1[jl],
          lambda2 = lambda2,
          tau = tau_now,
          rho = rho,
          maxit_MM = maxit_MM,
          tol_ADMM = tol_ADMM,
          maxit_ADMM = maxit_ADMM,
          tol_MM = tol_MM
        )
        
        hat.beta <- out$beta_update
        
        loss.re.tar[j, jl, jt] <- CV.criterion(
          x.test[[K]],
          indtest[[K]],
          hat.beta[K, ]
        )
      }
      if (verbose) print(paste0("tau=", jt, " over"))
    }
    
    if (verbose) print(paste0("fold ", j, " over"))
  }
  
  # ---------- 3. select lambda1 and tau ----------
  loss.mean.tar <- apply(loss.re.tar, c(2, 3), mean)
  opt_pos <- arrayInd(which.min(loss.mean.tar), dim(loss.mean.tar))
  
  optjl.tar <- opt_pos[1, 1]
  optjt.tar <- opt_pos[1, 2]
  
  lambdaopt.tar <- lambda1[optjl.tar]
  tauopt <- tau_grid[optjt.tar]
  
  outlist <- list(
    lambdaopt.tar = lambdaopt.tar,
    tauopt = tauopt,
    optjl.tar = optjl.tar,
    optjt.tar = optjt.tar,
    lambda1 = lambda1,
    tau_grid = tau_grid,
    loss.mean.tar = loss.mean.tar,
    loss.re.tar = loss.re.tar
  )
  class(outlist) <- "cv_TLP"
  return(outlist)
}



cv_TLP_3par_misloss <- function(x_list, ind_list, beta_int,
                                K, p,
                                lambda1, lambda2_grid, tau_grid,
                                rho, fold,
                                maxit_MM, tol_ADMM, maxit_ADMM,
                                tol_MM = 1e-5,
                                verbose = TRUE) {
  
  nlambda1 <- length(lambda1)
  nlambda2 <- length(lambda2_grid)
  ntau <- length(tau_grid)
  
  # ---------- 1. create CV splits ----------
  part.list <- vector("list", K)
  for (k in 1:K) {
    part.list[[k]] <- cv.part.balanced(
      n = nrow(x_list[[k]]),
      fold = fold,
      X_ind = ind_list[[k]]
    )
  }
  
  if (verbose) print("part.list OK")
  
  loss.re.tar <- array(
    NA_real_,
    dim = c(fold, nlambda1, nlambda2, ntau)
  )
  
  mis.re.tar <- array(
    NA_real_,
    dim = c(fold, nlambda1, nlambda2, ntau)
  )
  
  # ---------- 2. CV loop ----------
  for (j in 1:fold) {
    
    x.train <- vector("list", K)
    indtrain <- vector("list", K)
    x.test <- vector("list", K)
    indtest <- vector("list", K)
    
    for (k in 1:K) {
      train_id <- part.list[[k]]$trainMat[[j]]
      test_id  <- part.list[[k]]$testMat[[j]]
      
      x.train[[k]] <- x_list[[k]][train_id, , drop = FALSE]
      indtrain[[k]] <- ind_list[[k]][train_id]
      
      x.test[[k]] <- x_list[[k]][test_id, , drop = FALSE]
      indtest[[k]] <- ind_list[[k]][test_id]
    }
    
    stats_train <- compute_sigma_mu(x.train, indtrain)
    sigma_tilde_train <- make_sigma_tilde(stats_train$sigma, K, p, rho)
    
    for (j2 in 1:nlambda2) {
      lambda2_now <- lambda2_grid[j2]
      
      for (jt in 1:ntau) {
        tau_now <- tau_grid[jt]
        
        for (j1 in 1:nlambda1) {
          
          out <- TLP(
            stats = stats_train,
            sigma_tilde = sigma_tilde_train,
            beta_int = beta_int,
            K = K,
            p = p,
            lambda1 = lambda1[j1],
            lambda2 = lambda2_now,
            tau = tau_now,
            rho = rho,
            maxit_MM = maxit_MM,
            tol_ADMM = tol_ADMM,
            maxit_ADMM = maxit_ADMM,
            tol_MM = tol_MM
          )
          
          hat.beta <- out$beta_update
          
          loss.re.tar[j, j1, j2, jt] <- CV.criterion(
            x.test[[K]],
            indtest[[K]],
            hat.beta[K, ]
          )
          
          mis.re.tar[j, j1, j2, jt] <- CV.misclass(
            X_test = x.test[[K]],
            y_test = indtest[[K]],
            beta_train = hat.beta[K, ],
            X_train = x.train[[K]],
            y_train = indtrain[[K]]
          )
        }
      }
    }
    
    if (verbose) print(paste0("fold ", j, " over"))
  }
  
  # ---------- 3. summarize CV results ----------
  loss.mean.tar <- apply(loss.re.tar, c(2, 3, 4), mean)
  mis.mean.tar  <- apply(mis.re.tar,  c(2, 3, 4), mean)
  cand <- arrayInd(which.min(loss.mean.tar),dim(loss.mean.tar))
  # ---------- 4. among candidates: minimum misclassification ----------
  cand_mis <- sapply(seq_len(nrow(cand)), function(i) {
    mis.mean.tar[cand[i, 1], cand[i, 2], cand[i, 3]]
  })
  min_mis <- min(cand_mis)
  cand2 <- cand[abs(cand_mis - min_mis) < 1e-12, , drop = FALSE]
  
  # ---------- 5. tie-break 1: smaller tau ----------
  min_tau_index <- min(cand2[, 3])
  cand3 <- cand2[cand2[, 3] == min_tau_index, , drop = FALSE]
  
  # ---------- 6. tie-break 2: larger lambda1 ----------
  max_lambda1_index <- max(cand3[, 1])
  cand4 <- cand3[cand3[, 1] == max_lambda1_index, , drop = FALSE]
  
  # ---------- 7. tie-break 3: large lambda2 ----------
  best_i <- which.max(cand4[, 2])
  
  optj1.tar <- cand4[best_i, 1]
  optj2.tar <- cand4[best_i, 2]
  optjt.tar <- cand4[best_i, 3]
  
  lambda1opt.tar <- lambda1[optj1.tar]
  lambda2opt.tar <- lambda2_grid[optj2.tar]
  tauopt <- tau_grid[optjt.tar]
  
  outlist <- list(
    lambda1opt.tar = lambda1opt.tar,
    lambda2opt.tar = lambda2opt.tar,
    tauopt = tauopt,
    
    optj1.tar = optj1.tar,
    optj2.tar = optj2.tar,
    optjt.tar = optjt.tar,
    
    lambda1 = lambda1,
    lambda2_grid = lambda2_grid,
    tau_grid = tau_grid,
    
    loss.mean.tar = loss.mean.tar,
    loss.re.tar = loss.re.tar,
    mis.mean.tar = mis.mean.tar,
    mis.re.tar = mis.re.tar
  )
  
  class(outlist) <- "cv_TLP_3par"
  return(outlist)
}



ADMM_new = function(sigma_tilde,delta,beta_ad,zeta_ad,v_ad,zeta_m,
                    K,p,lambda1,lambda2,tau,rho,tol_ADMM,maxit_ADMM){
  l <- 1
  
  beta_new <- beta_ad
  zeta_new <- zeta_ad
  v_new <- v_ad
  primal_norm <- Inf
  
  while(l <= maxit_ADMM){
    beta_old <- beta_ad
    
    # 1. update beta^k, k = 1,...,K-1
    beta_new[1:(K - 1), ] <- AD1_rcpp(
      sigma_tilde = sigma_tilde,
      delta = delta,
      beta0 = beta_ad[K, ],
      zeta = zeta_ad,
      v = v_ad,
      beta_start_mat = beta_ad[1:(K - 1), , drop = FALSE],
      K = K,
      p = p,
      lambda1 = lambda1,
      rho = rho
    )
    # 2. update beta^0 / target beta
    beta_new[K, ] <- AD0_rcpp(
      sigma_tilde = sigma_tilde,
      delta = delta,
      beta = beta_new,
      zeta = zeta_ad,
      v = v_ad,
      beta_start0 = beta_ad[K, ],
      K = K,
      p = p,
      lambda1 = lambda1,
      rho = rho
    )
    
    # 3. update zeta
    zeta_new <- AD2(
      beta = beta_new,
      zeta_m = zeta_m,
      v = v_ad,
      K = K,
      p = p,
      lambda2 = lambda2,
      tau = tau,
      rho = rho
    )
    # 4. update scaled dual variable v
    beta0_mat <- matrix(beta_new[K, ], K - 1, p, byrow = TRUE)
    res <- zeta_new - beta0_mat + beta_new[1:(K - 1), , drop = FALSE]
    v_new <- v_ad + res
    
    
    # 5. stopping rule
    beta_change_ok <- SC(beta_new, beta_old, tol = tol_ADMM)
    primal_norm <- norm(res, "F") / sqrt((K - 1) * p)
    primal_ok <- primal_norm <= tol_ADMM
    
    if (beta_change_ok && primal_ok) {
      return(list(
        beta_new = beta_new,
        zeta_new = zeta_new,
        v_new = v_new,
        l = l,
        primal_norm = primal_norm,
        converged = TRUE
      ))
    }
    
    beta_ad <- beta_new
    zeta_ad <- zeta_new
    v_ad <- v_new
    
    l <- l + 1
    
    # if (l %% 1000 == 0) {
    #   print(l)
    # }
  }
  
  return(list(
    beta_new = beta_new,
    zeta_new = zeta_new,
    v_new = v_new,
    l = maxit_ADMM,
    primal_norm = primal_norm,
    converged = FALSE
  ))
}






#  Loss_S: primal loss function
Loss_S <- function(sigma, delta, beta, zeta, K, p, lambda1, lambda2, tau) {
  S <- 0
  
  for (k in 1:K) {
    bk <- beta[k, ]
    
    quad_k <- as.numeric(0.5 * crossprod(bk, sigma[[k]] %*% bk))
    lin_k  <- as.numeric(crossprod(bk, delta[[k]]))
    pen_k  <- lambda1 * sum(abs(bk))
    
    S <- S + quad_k - lin_k + pen_k
  }
  
  zeta_l1 <- rowSums(abs(zeta))
  S <- S + lambda2 * sum(pmin(tau, zeta_l1))
  
  return(as.numeric(S))
}








SC=function(mu_update,mu_init,tol){
  mu_inl2=norm(mu_init,"F")
  if(mu_inl2==0){
    res=norm((mu_update-mu_init),"F")
  } else{
    res=norm((mu_update-mu_init),"F")/mu_inl2
  }
  return(res<=tol)
}


stabilize_sigma <- function(sigmahat) {
  p <- ncol(sigmahat)
  
  sigmahat <- (sigmahat + t(sigmahat)) / 2
  
  eigvals <- eigen(sigmahat, only.values = TRUE)$values
  eigvals <- Re(eigvals)
  
  perturb <- max(max(eigvals) - p * min(eigvals), 0) / (p - 1)
  
  sigmahat <- sigmahat + diag(p) * perturb
  
  list(
    sigma = sigmahat,
    perturb = perturb,
    eig_min = min(eigvals),
    eig_max = max(eigvals)
  )
}

compute_one <- function(X, y) {
  X1 <- X[y == 1, , drop = FALSE]
  X2 <- X[y != 1, , drop = FALSE]
  
  n1 <- nrow(X1)
  n2 <- nrow(X2)
  
  mu1 <- colMeans(X1)
  mu2 <- colMeans(X2)
  delta <- mu2 - mu1
  
  X1c <- sweep(X1, 2, mu1, "-")
  X2c <- sweep(X2, 2, mu2, "-")
  
  sigma <- (crossprod(X1c) + crossprod(X2c)) / (n1 + n2 - 2)
  stab <- stabilize_sigma(sigma)
  sigma <- stab$sigma
  
  list(
    sigma = sigma,
    delta = delta,
    n = c(n1, n2)
  )
}



compute_sigma_mu <- function(x, x_ind) {
  if (is.matrix(x)) {
    return(compute_one(x, x_ind))
  }
  
  K <- length(x)
  sigma_list <- vector("list", K)
  delta_list <- vector("list", K)
  n_mat <- matrix(NA, K, 2)
  
  for (k in seq_len(K)) {
    out_k <- compute_one(x[[k]], x_ind[[k]])
    sigma_list[[k]] <- out_k$sigma
    delta_list[[k]] <- out_k$delta
    n_mat[k, ] <- out_k$n
  }
  
  list(
    sigma = sigma_list,
    delta = delta_list,
    n_x = n_mat
  )
}


AD1_rcpp <- function(sigma_tilde, delta, beta0, zeta, v,
                     beta_start_mat,
                     K, p, lambda1, rho,
                     maxIter = 500,
                     optTol = 1e-4,
                     zeroThreshold = 1e-4) {
  
  beta_hat <- matrix(0, K - 1, p)
  
  for (k in 1:(K - 1)) {
    
    delta_tilde <- as.numeric(delta[[k]]) -
      rho * as.numeric(zeta[k, ] - beta0 + v[k, ])
    
    out <- lasso_covariance_rcpp(
      XX = sigma_tilde[[k]],
      Xy = delta_tilde,
      beta_start = as.numeric(beta_start_mat[k, ]),
      lambda = lambda1,
      maxIter = maxIter,
      optTol = optTol,
      zeroThreshold = zeroThreshold
    )
    
    beta_hat[k, ] <- as.numeric(out$coefficients)
  }
  
  return(beta_hat)
}




AD0_rcpp <- function(sigma_tilde, delta, beta, zeta, v,
                     beta_start0,
                     K, p, lambda1, rho,
                     maxIter = 500,
                     optTol = 1e-4,
                     zeroThreshold = 1e-4) {
  
  delta_tilde <- as.numeric(delta[[K]]) +
    rho * colSums(zeta + beta[1:(K - 1), , drop = FALSE] + v)
  
  out <- lasso_covariance_rcpp(
    XX = sigma_tilde[[K]],
    Xy = as.numeric(delta_tilde),
    beta_start = as.numeric(beta_start0),
    lambda = lambda1,
    maxIter = maxIter,
    optTol = optTol,
    zeroThreshold = zeroThreshold
  )
  
  return(as.numeric(out$coefficients))
}

Prox=function(a,b){
  b_abs=abs(b)
  return((b_abs-a)*((b_abs-a)>0)*sign(b))
}

#  AD2: ADMM's 3 step; zeta^k
AD2 <- function(beta, zeta_m, v, K, p, lambda2, tau, rho){
  zeta_hat <- matrix(0, K - 1, p)
  th_v <- matrix(beta[K, ], K - 1, p, byrow = TRUE) -
    beta[1:(K - 1), , drop = FALSE] - v
  
  zeta_l1 <- rowSums(abs(zeta_m))
  
  for(k in 1:(K - 1)){
    if(zeta_l1[k] < tau){
      zeta_hat[k, ] <- Prox(lambda2 / rho, th_v[k, ])
    } else {
      zeta_hat[k, ] <- th_v[k, ]
    }
  }
  
  return(zeta_hat)
}


