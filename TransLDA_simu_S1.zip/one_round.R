one_round <- function() {
  # ---------- generate data ----------
  data <- DGP_data(K, p, nk, beta_target, sigma_target, ntest)
  X <- data$X
  y <- data$y
  Xtest <- data$Xtest
  ytest <- data$ytest
  
  # ---------- method: lpd for every domain ----------
  beta_all_lpd <- matrix(0, K, p)
  lam_lpd <- numeric(K)
  
  for (k in 1:K) {
    cv_out <- cv.lpd.fast(
      X[[k]], y[[k]],
      fold = fold,
      lambda = NULL,
      lambda.min = lam_min,
      lambda.max = lam_max,
      nlambda = nlam
    )
    
    lam_lpd[k] <- cv_out$lambdaopt
    prep_full <- lpd_prepare(X[[k]], y[[k]])
    beta_all_lpd[k, ] <- lpd_fast(prep_full, lam_lpd[k])
  }
  
  beta_target_only <- beta_all_lpd[K, ]
  
  # ---------- method: oracle case ----------
  if (is.null(inf_set)) {
    beta_oracle <- beta_target_only
  } else {
    X_A = X[[K]];y_A = y[[K]]
    for (i in rev(inf_set)){
      X_A = rbind(X[[i]],X_A)
      y_A = c(y[[i]],y_A)
    }
    cv_out_oracle=cv.lpd.fast(X_A,y_A,fold = fold,lambda = NULL,lambda.min = lam_min,lambda.max = lam_max,nlambda = nlam)
    prep_full = lpd_prepare(X_A, y_A)
    beta_oracle_pool = lpd_fast(prep_full,cv_out_oracle$lambdaopt)
    
    cv_out_debias <- cv.lpd.debias.fast(X[[K]],y[[K]],beta_oracle_pool,fold,
                                        lambda = NULL,lam_min,lam_max,nlam)
    prep_debias <- lpd_prepare_debias(X[[K]],y[[K]],beta_oracle_pool)
    zeta_hat <- lpd_fast_debias(prep = prep_debias,lambda = cv_out_debias$lambdaopt)
    beta_oracle = beta_oracle_pool + zeta_hat
  }  
  
  # ---------- method: blind case ----------
  X_blind <- X[[K]]
  y_blind <- y[[K]]
  
  for (i in (K - 1):1) {
    X_blind <- rbind(X[[i]], X_blind)
    y_blind <- c(y[[i]], y_blind)
  }
  
  cv_out_blind <- cv.lpd.fast(X_blind, y_blind,fold,lambda = NULL,lam_min,lam_max,nlam)
  prep_full <- lpd_prepare(X_blind, y_blind)
  beta_blind <- lpd_fast(prep_full, cv_out_blind$lambdaopt)    
  
  
  
  # ---------- tuning setting ----------
  contr_int <- sapply(1:(K - 1), function(k) {
    sum(abs(beta_all_lpd[k, ] - beta_all_lpd[K, ]))
  })
  
  contr <- sort(contr_int)
  tau_len <- numeric(K)
  tau_len[1] <- contr[1] / 5
  for (k in 1:(K - 2)) {
    tau_len[k + 1] <- (contr[k] + contr[k + 1]) / 2
  }
  tau_len[K] <- contr[K - 1] * 5
  tau_grid <- tau_len
  
  rho = rho_tlp 
  lambda1 <- seq(lam1_tlp_min,lam1_tlp_max, length.out = lam1_tlp_nlam) * mean(lam_lpd)
  lambda2_grid <-rho*mean(lam_lpd)
  # lambda2_grid <-c(0.5,1,2)*rho*mean(lam_lpd)
   
  # ---------- DC-ADMM CV ----------
  cv.tlp.out <- cv_TLP_3par_misloss(
    x_list = X,
    ind_list = y,
    beta_int = beta_all_lpd,
    K = K,
    p = p,
    lambda1 = lambda1,
    lambda2_grid = lambda2_grid,
    tau_grid = tau_grid,
    rho = rho,
    fold = fold,
    maxit_MM = maxit_MM_tlp,
    tol_ADMM = 1e-4,
    maxit_ADMM = maxit_admm_tlp,
    tol_MM = 1e-4,
    verbose = TRUE
  )
  
  stats_full <- compute_sigma_mu(X, y)
  sigma_tilde_full <- make_sigma_tilde(stats_full$sigma, K, p, rho)
  
  out_final <- TLP(
    stats = stats_full,
    sigma_tilde = sigma_tilde_full,
    beta_int = beta_all_lpd,
    K = K,
    p = p,
    lambda1 = cv.tlp.out$lambda1opt.tar,
    lambda2 = cv.tlp.out$lambda2opt.tar,
    tau = cv.tlp.out$tauopt,
    rho = rho,
    maxit_MM = maxit_MM_tlp,
    tol_ADMM = 1e-4,
    maxit_ADMM = maxit_admm_tlp,
    tol_MM = 1e-4
  )
  
  
  beta_tlp <- out_final$beta_update
  hat_true_A <- as.numeric(apply(abs(out_final$zeta_update), 1, sum) < cv.tlp.out$tauopt)
  
  # ---------- evaluation ----------
  mis <- matrix(
    c(
      out_mis(Xtest, ytest, beta_target_only),
      out_mis(Xtest, ytest, beta_blind),
      out_mis(Xtest, ytest, beta_oracle),
      out_mis(Xtest, ytest, beta_tlp[K, ])
    ),
    nrow = 1
  )
  
  colnames(mis) <- c("Naive LPD", "Blind Pooling", "Oracle TLDA", "Non-oracle TLDA")
  
  norm_re <- matrix(
    c(
      norm(beta_target_only - beta_target[K, ], "2"),
      norm(beta_blind - beta_target[K, ], "2"),
      norm(beta_oracle - beta_target[K, ], "2"),
      norm(beta_tlp[K, ] - beta_target[K, ], "2")
    ),
    nrow = 1
  )
  
  colnames(norm_re) <- c("Naive LPD", "Blind Pooling", "Oracle TLDA", "Non-oracle TLDA")
  
  sigma_norm_error <- function(bhat, beta0, Sigma0) {
    diff_error <- bhat - beta0
    sqrt(as.numeric(t(diff_error) %*% Sigma0 %*% diff_error))
  }
  norm_weighted = matrix(
    c(
      sigma_norm_error(beta_target_only,beta_target[K, ], sigma_target[[K]]),
      sigma_norm_error(beta_blind,beta_target[K, ], sigma_target[[K]]),
      sigma_norm_error(beta_oracle,beta_target[K, ], sigma_target[[K]]),
      sigma_norm_error(beta_tlp[K, ],beta_target[K, ], sigma_target[[K]])
    ),
    nrow = 1
  )
  colnames(norm_weighted) <- c("Naive LPD", "Blind Pooling", "Oracle TLDA", "Non-oracle TLDA")
  
  beta_re <- cbind(
    beta_target_only,
    beta_blind,
    beta_oracle,
    beta_tlp[K, ]
  )
  
  colnames(beta_re) <- c("Naive LPD", "Blind Pooling", "Oracle TLDA", "Non-oracle TLDA")
  
  return(list(
    norm_re = norm_re,
    norm_weighted = norm_weighted,
    mis = mis,
    hat_true_A = hat_true_A,
    beta_re = beta_re,
    beta_all_lpd = beta_all_lpd,
    beta_tlp = beta_tlp,
    lambda1opt = cv.tlp.out$lambda1opt.tar,
    lambda2opt = cv.tlp.out$lambda2opt.tar,
    tauopt = cv.tlp.out$tauopt,
    loss.mean.tar = cv.tlp.out$loss.mean.tar,
    tau_grid=tau_grid,
    lambda1 = lambda1,
    lambda2_grid = lambda2_grid,
    contr = contr,
    best_lam12tau = c(cv.tlp.out$optj1.tar,cv.tlp.out$optj2.tar,cv.tlp.out$optjt.tar)
  ))
}